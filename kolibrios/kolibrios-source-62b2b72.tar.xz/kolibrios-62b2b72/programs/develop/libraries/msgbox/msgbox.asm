format MS COFF
public EXPORTS
section '.flat' code readable align 16

include '../../../macros.inc'
include '../../../KOSfuncs.inc'
include 'strlen.inc'

MB_FIRST_BUT_ID equ 3 ;�����䨪��� 1-� ������ �� ᮮ�饭��
MB_MAX_BUT equ 8 ;���ᨬ��쭮� �᫮ ������ � ᮮ�饭��
MB_BUT_HEIGHT equ 20 ;���� ������ �� ᮮ�饭��
CHAR_WIDTH equ 6 ;�ਭ� 1-� �㪢� ⥪��
MB_BUT_OTY_1 equ  5 ;���⨪����(�) �����(�) �����: ���������� ���� � ⥪�⮬, ⥪�⮬ ��������
;--- ������ �� �������, 㪠����� ����ᠬ�: <-?->, ��� ��� ⥪�� ---
MB_BUT_OTX_1 equ  5 ;[<-?->Caption.....]
MB_BUT_OTX_2 equ 10 ;[<-?->Caption<-?->]
MB_BUT_OTX_3 equ 15 ;[<-?->Caption<-?->]<-?->
MB_TEXT_OFFSET equ 2 ;ᬥ饭��, �� ���஬� ��稭������ ⥪�� ��������� ����

align 4
start:
  mcall SF_STYLE_SETTINGS,SSF_GET_COLORS,sc,sizeof.system_colors
  mcall SF_SET_EVENTS_MASK, EVM_MOUSE + EVM_BUTTON + EVM_KEY + EVM_REDRAW

  ;-- clear id pressed button ---
  mov ebx,[mb_text]
  mov al,byte[ebx]
  add al,MB_FIRST_BUT_ID
  dec al
  mov byte[mb_key_foc],al

  push [mb_text]
  call MsgBoxReInit

align 4
red_win:
  mcall SF_REDRAW,SSF_BEGIN_DRAW

  xor eax,eax
  mov bx,word[mb_left]
  shl ebx,16
  mov bx,word[mb_width]
  mov cx,word[mb_top]
  shl ecx,16
  mov cx,word[mb_height]
  mov edx,[sc.work]
  or  edx,0x33000000
  mov edi,[mb_text]
  add edi,MB_TEXT_OFFSET ;Caption
  mcall

  mcall SF_THREAD_INFO,mb_procinfo,-1
  mov eax,dword[mb_procinfo.client_box.width]

  sub eax,[but_width]
  shr eax,1
  add eax,MB_BUT_OTX_1
  mov [ot_left],eax

  mov bx,MB_BUT_OTX_1
  shl ebx,16
  mov bx,MB_BUT_OTY_1
  mov ecx,[sc.work_text]
  mov edx,[txtMsg]

  @@:
    mov esi,edx
    call strlen
    call linlen

    or eax,eax
    jz @f

    mov esi,eax
    push eax
      mcall SF_DRAW_TEXT
    pop eax

    add edx,eax
    cmp byte[edx],0
    je @f
    inc edx

    add ebx,10 ; move <--y-->
    jmp @b
  @@:

  call MsgBoxDrawAllBut
  mcall SF_REDRAW,SSF_END_DRAW

align 4
still:
  mcall SF_WAIT_EVENT

  cmp al,EV_REDRAW
  jz red_win
  cmp al,EV_KEY
  jz key
  cmp al,EV_BUTTON
  jz button

  jmp still

align 4
key:
  mcall SF_GET_KEY
  cmp ah,13
  jne @f
    mov ah,[mb_key_foc]
    jmp close
  @@:

  cmp ah,176 ;Left
  jne .no_left
  cmp [mb_key_foc],MB_FIRST_BUT_ID
  jg @f
    mov al,[mb_key_max]
    add [mb_key_foc],al
  @@:
    dec [mb_key_foc]
    call MsgBoxDrawAllBut
  .no_left:

  cmp ah,9 ;Tab
  je @f
  cmp ah,179 ;Right
  je @f
	jmp .no_right
  @@:
  mov al,[mb_key_max]
  add al,MB_FIRST_BUT_ID
  cmp [mb_key_foc],al
  je .no_right
    inc [mb_key_foc]
    cmp [mb_key_foc],al
    jl @f
      mov [mb_key_foc],MB_FIRST_BUT_ID
    @@:
    call MsgBoxDrawAllBut
  .no_right:

  jmp still

align 4
button:
  mcall SF_GET_BUTTON
  cmp ah,MB_FIRST_BUT_ID
  jge close
  cmp ah,1
  jne still

;.exit:
  mov ah,MB_FIRST_BUT_ID
  dec ah
close:
  sub ah,MB_FIRST_BUT_ID
  inc ah
  mov ebx,[mb_text]
  mov byte[ebx],ah

  ;*** call msgbox functions ***
  or ah,ah
  jz @f
  cmp dword[mb_funct],0
  je @f
    xor ebx,ebx
    mov bl,ah
    dec bl
    shl bx,2 ;bx=bx*4
    add ebx,dword[mb_funct]
    cmp dword[ebx],0
    je @f
      call dword[ebx]
  @@:
  mcall SF_TERMINATE_PROCESS

align 4
MsgBoxDrawAllBut:
  mov ebx,[ot_left]
  shl ebx,16
  mov bx,word[ot_top]
  add bx,MB_BUT_OTY_1

  ; Buttons ...
  push edi
  mov edi,txtBut
  mov edx,[edi]

  mov ecx,MB_FIRST_BUT_ID
  @@:
    ;eax = len button caption text
    mov esi,edx
    call strlen

    or eax,eax
    jz @f

    call MsgBoxDrawButton
    inc ecx

    add edi,4
    cmp edi,endBut
    jge @f
    mov edx,[edi]

    push bx
    ror ebx,16
      imul esi,CHAR_WIDTH
      add esi,MB_BUT_OTX_3
      add ebx,esi ; ...
    ror ebx,16
    pop bx

    jmp @b
  @@:
  pop edi
  ret

;input:
; ecx = button id
align 4
MsgBoxDrawButton:
  push ecx

  ;button
  push eax ebx edx
    mov edx,ecx
    imul eax,CHAR_WIDTH
    add eax,MB_BUT_OTX_2

    mov esi,[sc.work_button]
    cmp cl,[mb_key_foc]
    jne @f
      mov esi,[sc.work_button_text]
    @@:

    mov cx,bx
    sub cx,MB_BUT_OTY_1
    shl ecx,16
    mov cx,MB_BUT_HEIGHT
    ror ebx,16
    sub bx,MB_BUT_OTX_1
    ror ebx,16
    mov bx,ax

    mcall SF_DEFINE_BUTTON
  pop edx ebx eax

  ;caption
  mov ecx,[sc.work_button_text]
  cmp esi,ecx
  jne @f
    mov ecx,[sc.work_button]
  @@:
  mov esi,eax
  mcall SF_DRAW_TEXT

  pop ecx
  ret

align 4
MsgBoxReInit:
  push ebp
  mov ebp,esp
    m2m dword[mb_text],dword[ebp+8]
  push eax ebx ecx edi esi

  mov esi,[mb_text]
  add esi,MB_TEXT_OFFSET
  call strlen
  inc esi ;add terminated zero
  add esi,eax ;add len of caption
  mov [txtMsg],esi

  ;--- calc window width ---
  push eax ebx esi
  .cycle:
  call strlen
  mov ebx,eax
  call linlen
  add esi,eax
  sub ebx,eax
  imul eax,6
  add eax,10+2*SF_DRAW_TEXT
  cmp [mb_width],ax
  jge @f
    mov [mb_width],ax
  @@:
  inc esi
  cmp ebx,5 ;length of the remaining text
  jg .cycle
  pop esi ebx eax

  ;--- go to first button text --- buttons 1...MB_MAX_BUT
  mov ebx,txtBut
  mov cx,MB_MAX_BUT
  @@:
    call strlen
    add esi,eax ;add len of caption
    inc esi ;add terminated zero

    mov dword[ebx],esi
    cmp byte[esi],0
    je @f
    add ebx,4
  loop @b
  @@:

  ;--- calc button top ---
  mov eax,1
  mov ebx,[txtMsg]
  @@:
    inc ebx
    cmp byte[ebx],0
    je @f
    cmp byte[ebx],13
    jne @b
    inc eax
    jmp @b
  @@:
  imul eax,10
  add eax,2*MB_BUT_OTY_1
  mov [ot_top],eax

  ;--- calc window height ---
  add eax,MB_BUT_OTY_1
  add eax,MB_BUT_HEIGHT
  add ax,5 ;height of border
  mov [mb_height],ax
  mcall SF_STYLE_SETTINGS,SSF_GET_SKIN_HEIGHT
  add [mb_height],ax

  ;--- calc window top ---
  mcall SF_GET_SCREEN_SIZE
  mov word[mb_top],ax
  mov ax,word[mb_height]
  sub word[mb_top],ax
  shr word[mb_top],1
  ;---
  shr eax,16
  mov word[mb_left],ax
  mov ax,word[mb_width]
  sub word[mb_left],ax
  shr word[mb_left],1

  ;--- calc button width ---
  xor ebx,ebx
  xor ecx,ecx
  mov esi,[txtBut]
  mov byte[mb_key_max],0
  @@:
    cmp byte[esi],0
    je @f
    inc ecx
    call strlen
    add esi,eax
    inc esi
    inc byte[mb_key_max]
    add ebx,eax
    jmp @b
  @@:

  imul ebx,CHAR_WIDTH
  imul ecx,MB_BUT_OTX_3
  add ebx,ecx
  add ebx,MB_BUT_OTX_2
  sub ebx,MB_BUT_OTX_3
  mov [but_width],ebx

  pop esi edi ecx ebx eax
  pop ebp
  ret 4

;input:
; [esp+8] = pointer to msgbox text
; [esp+12] = thread stack
align 4
MsgBoxCreate:
  push ebp
  mov ebp,esp
    m2m dword[mb_text],dword[ebp+8]
    push eax ebx ecx edx

	mcall SF_THREAD_CONTROL,SSF_CREATE_THREAD,start,[ebp+12]

    mov dword[mb_funct],0
    pop edx ecx ebx eax
  pop ebp
  ret 8

;input:
; [esp+8] = pointer to msgbox functions pointers
align 4
MsgBoxSetFunctions:
  push ebp
  mov ebp,esp
    m2m dword[mb_funct],dword[ebp+8]
  pop ebp
  ret 4

;--- data ---
  txtMsg dd 0 ;㪠��⥫� �� ��砫� ⥪�� ᮮ�饭��
  txtBut rd MB_MAX_BUT ;㪠��⥫� �� ��砫� ⥪�� �����ᥩ ������
  endBut:
  ot_left dd 0 ;����� ᫥�� (��� �ᮢ���� ������)
  ot_top dd 0 ;����� ᢥ��� (��� �ᮢ���� ������)
  but_width dd 0 ;�ਭ� ��� ������ + ������ ����� ����
  ;--- ࠧ���� �� ��࠭� ���� ᮮ�饭�� ---
  mb_left dw 0
  mb_width dw 300
  mb_top dw 0
  mb_height dw 50
  mb_key_foc db MB_FIRST_BUT_ID ;������ � 䮪�� (� ��⮬ MB_FIRST_BUT_ID)
  mb_key_max db 1 ;�᫮ ��� ������ ᮮ�饭��
;--------------------------------------------------
  sc system_colors
  mb_procinfo process_information ;㪠��⥫� �� �������� process_information த�⥫�᪮�� ����
  mb_text dd 0 ;msgbox_1 ;㪠��⥫� ����� ��� ᮮ�饭�� (����� ��।������ ����)
  mb_funct dd 0 ;pointer to functions
;--------------------------------------------------
align 16
EXPORTS:
  dd sz_mb_create, MsgBoxCreate
  dd sz_mb_reinit, MsgBoxReInit
  dd sz_mb_setfunctions, MsgBoxSetFunctions
  dd 0,0
  sz_mb_create db 'mb_create',0
  sz_mb_reinit db 'mb_reinit',0
  sz_mb_setfunctions db 'mb_setfunctions',0