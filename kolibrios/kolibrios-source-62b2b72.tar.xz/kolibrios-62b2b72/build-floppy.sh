#!/bin/sh
# Rebuild the Hummingbird KolibriOS floppy from this source tree, without tup.
# Generated from the tup build graph of KolibriOS 62b2b72 (en_US, FASM/NASM only, CONFIG_HUMMINGBIRD_IMG_ONLY).
# Needs: fasm, nasm, mtools (mformat/mmd/mcopy), dd, gcc+make (for kpack/kerpack, built first from programs/other/kpack/kerpack_linux),
# python3 (fasm timestamp shim), and faketime (optional, for byte-identical images).
set -e
# Reproducibility: FASM writes the current time into driver/library headers, and mtools
# stamps file times. Re-run this script under a fixed clock so every build is identical:
if [ -z "$HUMMINGBIRD_FIXED_CLOCK" ] && command -v faketime >/dev/null 2>&1; then
  HUMMINGBIRD_FIXED_CLOCK=1 exec faketime "2026-11-01 00:00:00" "$0" "$@"
fi
ROOT=$(cd "$(dirname "$0")" && pwd)
export PATH="$ROOT/hummingbird-tools:$ROOT/programs/other/kpack/kerpack_linux:$PATH"   # fasm shim zeroes header timestamps
( cd "$ROOT/programs/other/kpack/kerpack_linux" && make -s kpack kerpack )
mkdir -p "$ROOT/build-en_US/data/en_US"
mkdir -p "$ROOT/build-en_US/drivers/audio"
mkdir -p "$ROOT/build-en_US/drivers/audio/infinity"
mkdir -p "$ROOT/build-en_US/drivers/audio/intel_hda"
mkdir -p "$ROOT/build-en_US/drivers/audio/sb16"
mkdir -p "$ROOT/build-en_US/drivers/disk"
mkdir -p "$ROOT/build-en_US/drivers/ethernet"
mkdir -p "$ROOT/build-en_US/drivers/i2chid"
mkdir -p "$ROOT/build-en_US/drivers/mouse"
mkdir -p "$ROOT/build-en_US/drivers/mouse/ps2mouse4d"
mkdir -p "$ROOT/build-en_US/drivers/serial"
mkdir -p "$ROOT/build-en_US/drivers/usb"
mkdir -p "$ROOT/build-en_US/drivers/usb/usbftdi"
mkdir -p "$ROOT/build-en_US/drivers/usb/usbhid"
mkdir -p "$ROOT/build-en_US/drivers/usb/usbnet"
mkdir -p "$ROOT/build-en_US/drivers/usb/usbother"
mkdir -p "$ROOT/build-en_US/drivers/usb/xhci"
mkdir -p "$ROOT/build-en_US/drivers/video"
mkdir -p "$ROOT/build-en_US/kernel/trunk"
mkdir -p "$ROOT/build-en_US/kernel/trunk/bootloader"
mkdir -p "$ROOT/build-en_US/programs/demos/3dcube2"
mkdir -p "$ROOT/build-en_US/programs/demos/3dwav"
mkdir -p "$ROOT/build-en_US/programs/demos/aclock"
mkdir -p "$ROOT/build-en_US/programs/demos/bcdclk"
mkdir -p "$ROOT/build-en_US/programs/demos/buddhabrot"
mkdir -p "$ROOT/build-en_US/programs/demos/crownscr"
mkdir -p "$ROOT/build-en_US/programs/demos/eyes"
mkdir -p "$ROOT/build-en_US/programs/demos/firework"
mkdir -p "$ROOT/build-en_US/programs/demos/free3d04"
mkdir -p "$ROOT/build-en_US/programs/demos/movback"
mkdir -p "$ROOT/build-en_US/programs/demos/plasma"
mkdir -p "$ROOT/build-en_US/programs/demos/ray"
mkdir -p "$ROOT/build-en_US/programs/demos/spiral"
mkdir -p "$ROOT/build-en_US/programs/demos/tinyfrac"
mkdir -p "$ROOT/build-en_US/programs/demos/trantest"
mkdir -p "$ROOT/build-en_US/programs/demos/tube"
mkdir -p "$ROOT/build-en_US/programs/demos/unvwater"
mkdir -p "$ROOT/build-en_US/programs/demos/view3ds"
mkdir -p "$ROOT/build-en_US/programs/demos/web"
mkdir -p "$ROOT/build-en_US/programs/demos/zeroline"
mkdir -p "$ROOT/build-en_US/programs/develop/cObj"
mkdir -p "$ROOT/build-en_US/programs/develop/charsets"
mkdir -p "$ROOT/build-en_US/programs/develop/entropyview"
mkdir -p "$ROOT/build-en_US/programs/develop/fasm/1.73"
mkdir -p "$ROOT/build-en_US/programs/develop/h2d2b"
mkdir -p "$ROOT/build-en_US/programs/develop/heed"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/TinyGL/asm_fork"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/TinyGL/asm_fork/examples"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/box_lib"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/buf2d"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/console_coff"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/dll"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/fontRasterWorks_unicode"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/http"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/libcrash"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/libs-dev/libgfx"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/libs-dev/libimg"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/libs-dev/libini"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/libs-dev/libio"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/msgbox"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/network"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/proc_lib"
mkdir -p "$ROOT/build-en_US/programs/develop/libraries/sorter"
mkdir -p "$ROOT/build-en_US/programs/develop/mstate"
mkdir -p "$ROOT/build-en_US/programs/develop/mtdbg"
mkdir -p "$ROOT/build-en_US/programs/develop/scancode"
mkdir -p "$ROOT/build-en_US/programs/develop/tinypad"
mkdir -p "$ROOT/build-en_US/programs/fs/kfar"
mkdir -p "$ROOT/build-en_US/programs/fs/kfar/kfar_arc"
mkdir -p "$ROOT/build-en_US/programs/fs/lod"
mkdir -p "$ROOT/build-en_US/programs/fs/opendial"
mkdir -p "$ROOT/build-en_US/programs/fs/unz"
mkdir -p "$ROOT/build-en_US/programs/games/15"
mkdir -p "$ROOT/build-en_US/programs/games/MSquare"
mkdir -p "$ROOT/build-en_US/programs/games/c4"
mkdir -p "$ROOT/build-en_US/programs/games/gomoku"
mkdir -p "$ROOT/build-en_US/programs/games/lines"
mkdir -p "$ROOT/build-en_US/programs/games/max-freecell"
mkdir -p "$ROOT/build-en_US/programs/games/pipes"
mkdir -p "$ROOT/build-en_US/programs/games/pong"
mkdir -p "$ROOT/build-en_US/programs/games/pong3"
mkdir -p "$ROOT/build-en_US/programs/games/rsquare"
mkdir -p "$ROOT/build-en_US/programs/games/snake"
mkdir -p "$ROOT/build-en_US/programs/games/sq_game"
mkdir -p "$ROOT/build-en_US/programs/games/sudoku"
mkdir -p "$ROOT/build-en_US/programs/games/sw"
mkdir -p "$ROOT/build-en_US/programs/games/tanks"
mkdir -p "$ROOT/build-en_US/programs/games/tetris"
mkdir -p "$ROOT/build-en_US/programs/media/FillScr"
mkdir -p "$ROOT/build-en_US/programs/media/animage"
mkdir -p "$ROOT/build-en_US/programs/media/kiv"
mkdir -p "$ROOT/build-en_US/programs/media/listplay"
mkdir -p "$ROOT/build-en_US/programs/media/midamp"
mkdir -p "$ROOT/build-en_US/programs/media/mp3info"
mkdir -p "$ROOT/build-en_US/programs/media/palitra"
mkdir -p "$ROOT/build-en_US/programs/media/piano"
mkdir -p "$ROOT/build-en_US/programs/media/scrshoot"
mkdir -p "$ROOT/build-en_US/programs/media/startmus"
mkdir -p "$ROOT/build-en_US/programs/media/volume"
mkdir -p "$ROOT/build-en_US/programs/media/zsea/plugins/png"
mkdir -p "$ROOT/build-en_US/programs/network/ftpc"
mkdir -p "$ROOT/build-en_US/programs/network/ftpd"
mkdir -p "$ROOT/build-en_US/programs/network/httpget"
mkdir -p "$ROOT/build-en_US/programs/network/ircc"
mkdir -p "$ROOT/build-en_US/programs/network/netcfg"
mkdir -p "$ROOT/build-en_US/programs/network/netstat"
mkdir -p "$ROOT/build-en_US/programs/network/netsurf"
mkdir -p "$ROOT/build-en_US/programs/network/nslookup"
mkdir -p "$ROOT/build-en_US/programs/network/pasta"
mkdir -p "$ROOT/build-en_US/programs/network/ping"
mkdir -p "$ROOT/build-en_US/programs/network/sntp"
mkdir -p "$ROOT/build-en_US/programs/network/synergyc"
mkdir -p "$ROOT/build-en_US/programs/network/telnet"
mkdir -p "$ROOT/build-en_US/programs/network/tftpc"
mkdir -p "$ROOT/build-en_US/programs/network/vncc"
mkdir -p "$ROOT/build-en_US/programs/network/zeroconf"
mkdir -p "$ROOT/build-en_US/programs/other/Timer"
mkdir -p "$ROOT/build-en_US/programs/other/calc"
mkdir -p "$ROOT/build-en_US/programs/other/calcplus"
mkdir -p "$ROOT/build-en_US/programs/other/ha"
mkdir -p "$ROOT/build-en_US/programs/other/kpack"
mkdir -p "$ROOT/build-en_US/programs/other/madmouse"
mkdir -p "$ROOT/build-en_US/programs/other/mousepos"
mkdir -p "$ROOT/build-en_US/programs/other/pipet"
mkdir -p "$ROOT/build-en_US/programs/other/rtfread"
mkdir -p "$ROOT/build-en_US/programs/system/MyKey"
mkdir -p "$ROOT/build-en_US/programs/system/apm"
mkdir -p "$ROOT/build-en_US/programs/system/board"
mkdir -p "$ROOT/build-en_US/programs/system/calendar"
mkdir -p "$ROOT/build-en_US/programs/system/colrdial"
mkdir -p "$ROOT/build-en_US/programs/system/cpu"
mkdir -p "$ROOT/build-en_US/programs/system/cropflat"
mkdir -p "$ROOT/build-en_US/programs/system/dbgboard"
mkdir -p "$ROOT/build-en_US/programs/system/docky"
mkdir -p "$ROOT/build-en_US/programs/system/docpack"
mkdir -p "$ROOT/build-en_US/programs/system/end/light"
mkdir -p "$ROOT/build-en_US/programs/system/eskin"
mkdir -p "$ROOT/build-en_US/programs/system/gmon"
mkdir -p "$ROOT/build-en_US/programs/system/hdd_info"
mkdir -p "$ROOT/build-en_US/programs/system/icon_new"
mkdir -p "$ROOT/build-en_US/programs/system/launcher"
mkdir -p "$ROOT/build-en_US/programs/system/loaddrv"
mkdir -p "$ROOT/build-en_US/programs/system/magnify"
mkdir -p "$ROOT/build-en_US/programs/system/menu"
mkdir -p "$ROOT/build-en_US/programs/system/mousemul"
mkdir -p "$ROOT/build-en_US/programs/system/notify3"
mkdir -p "$ROOT/build-en_US/programs/system/open"
mkdir -p "$ROOT/build-en_US/programs/system/rdsave"
mkdir -p "$ROOT/build-en_US/programs/system/reshare"
mkdir -p "$ROOT/build-en_US/programs/system/scrsaver"
mkdir -p "$ROOT/build-en_US/programs/system/searchap"
mkdir -p "$ROOT/build-en_US/programs/system/setup"
mkdir -p "$ROOT/build-en_US/programs/system/skincfg"
mkdir -p "$ROOT/build-en_US/programs/system/taskbar"
mkdir -p "$ROOT/build-en_US/programs/system/terminal"
mkdir -p "$ROOT/build-en_US/programs/system/tinfo"
mkdir -p "$ROOT/build-en_US/programs/system/zkey"
mkdir -p "$ROOT/build-en_US/programs/testing/cpuid"
mkdir -p "$ROOT/build-en_US/programs/testing/disptest"
mkdir -p "$ROOT/build-en_US/programs/testing/genfiles"
mkdir -p "$ROOT/build-en_US/programs/testing/kbd"
mkdir -p "$ROOT/build-en_US/programs/testing/pcidev"
mkdir -p "$ROOT/build-en_US/programs/testing/protection"
mkdir -p "$ROOT/build-en_US/skins/Leency/Shkvorka"
( cd "$ROOT/kernel/trunk" && echo lang fix en_US > ../../build-en_US/kernel/trunk/lang.inc )
( cd "$ROOT/kernel/trunk" && INCLUDE='../../programs;../../build-en_US/kernel/trunk' fasm -m 262144 kernel.asm ../../build-en_US/kernel/trunk/kernel.mnt -s ../../build-en_US/kernel/trunk/kernel.mnt.fas&& kerpack ../../build-en_US/kernel/trunk/kernel.mnt )
( cd "$ROOT/programs/develop/heed" && echo lang fix en_US > ../../../build-en_US/programs/develop/heed/lang.inc )
( cd "$ROOT/programs/develop/heed" && INCLUDE='../..;../../../build-en_US/programs/develop/heed' fasm heed.asm ../../../build-en_US/programs/develop/heed/heed && kpack --nologo "../../../build-en_US/programs/develop/heed/heed" )
( cd "$ROOT/programs/develop/mtdbg" && fasm mtdbg.asm ../../../build-en_US/programs/develop/mtdbg/mtdbg && kpack --nologo "../../../build-en_US/programs/develop/mtdbg/mtdbg" )
( cd "$ROOT/programs/other/ha" && echo lang fix en_US > ../../../build-en_US/programs/other/ha/lang.inc )
( cd "$ROOT/programs/other/ha" && INCLUDE='../..;../../../build-en_US/programs/other/ha' fasm HA.ASM ../../../build-en_US/programs/other/ha/HA && kpack --nologo "../../../build-en_US/programs/other/ha/HA" )
( cd "$ROOT/programs/other/ha" && INCLUDE='../..;../../../build-en_US/programs/other/ha' fasm HACONFIG.ASM ../../../build-en_US/programs/other/ha/HACONFIG && kpack --nologo "../../../build-en_US/programs/other/ha/HACONFIG" )
( cd "$ROOT/programs/develop/scancode" && echo lang fix en_US > ../../../build-en_US/programs/develop/scancode/lang.inc )
( cd "$ROOT/programs/develop/scancode" && INCLUDE='../..;../../../build-en_US/programs/develop/scancode' fasm scancode.asm ../../../build-en_US/programs/develop/scancode/scancode && kpack --nologo "../../../build-en_US/programs/develop/scancode/scancode" )
( cd "$ROOT/programs/fs/kfar" && echo lang fix en_US > ../../../build-en_US/programs/fs/kfar/lang.inc )
( cd "$ROOT/programs/fs/kfar" && INCLUDE='../..;../../../build-en_US/programs/fs/kfar' fasm kfar.asm ../../../build-en_US/programs/fs/kfar/kfar && kpack --nologo "../../../build-en_US/programs/fs/kfar/kfar" )
( cd "$ROOT/programs/system/icon_new" && echo lang fix en_US > ../../../build-en_US/programs/system/icon_new/lang.inc )
( cd "$ROOT/programs/system/icon_new" && INCLUDE='../..;../../../build-en_US/programs/system/icon_new' fasm icon.asm ../../../build-en_US/programs/system/icon_new/icon && kpack --nologo "../../../build-en_US/programs/system/icon_new/icon" )
( cd "$ROOT/programs/fs/opendial" && fasm opendial.asm ../../../build-en_US/programs/fs/opendial/opendial && kpack --nologo "../../../build-en_US/programs/fs/opendial/opendial" )
( cd "$ROOT/programs/system/docky" && fasm docky.asm ../../../build-en_US/programs/system/docky/docky && kpack --nologo "../../../build-en_US/programs/system/docky/docky" )
( cd "$ROOT/programs/system/menu" && echo lang fix en_US > ../../../build-en_US/programs/system/menu/lang.inc )
( cd "$ROOT/programs/system/menu" && INCLUDE='../..;../../../build-en_US/programs/system/menu' fasm menu.asm ../../../build-en_US/programs/system/menu/menu && kpack --nologo "../../../build-en_US/programs/system/menu/menu" )
( cd "$ROOT/programs/fs/lod" && fasm lod.asm ../../../build-en_US/programs/fs/lod/lod && kpack --nologo "../../../build-en_US/programs/fs/lod/lod" )
( cd "$ROOT/programs/system/notify3" && fasm notify.asm ../../../build-en_US/programs/system/notify3/notify && kpack --nologo "../../../build-en_US/programs/system/notify3/notify" )
( cd "$ROOT/programs/games/15" && echo lang fix en_US > ../../../build-en_US/programs/games/15/lang.inc )
( cd "$ROOT/programs/games/15" && INCLUDE='../..;../../../build-en_US/programs/games/15' fasm 15.ASM ../../../build-en_US/programs/games/15/15 && kpack --nologo "../../../build-en_US/programs/games/15/15" )
( cd "$ROOT/programs/system/open" && echo lang fix en_US > ../../../build-en_US/programs/system/open/lang.inc )
( cd "$ROOT/programs/system/open" && INCLUDE='../..;../../../build-en_US/programs/system/open' fasm open.asm ../../../build-en_US/programs/system/open/open && kpack --nologo "../../../build-en_US/programs/system/open/open" )
( cd "$ROOT/programs/games/max-freecell" && INCLUDE='../..' fasm -dlang=en_US freecell.asm ../../../build-en_US/programs/games/max-freecell/freecell && kpack --nologo "../../../build-en_US/programs/games/max-freecell/freecell" )
( cd "$ROOT/programs/system/reshare" && INCLUDE='../..' fasm -dlang=en_US reshare.asm ../../../build-en_US/programs/system/reshare/reshare&& kpack --nologo "../../../build-en_US/programs/system/reshare/reshare" )
( cd "$ROOT/programs/system/scrsaver" && INCLUDE='../..' fasm scrsaver.asm ../../../build-en_US/programs/system/scrsaver/scrsaver && kpack --nologo "../../../build-en_US/programs/system/scrsaver/scrsaver" )
( cd "$ROOT/programs/games/gomoku" && echo lang fix en_US > ../../../build-en_US/programs/games/gomoku/lang.inc )
( cd "$ROOT/programs/games/gomoku" && INCLUDE='../..;../../../build-en_US/programs/games/gomoku' fasm gomoku.asm ../../../build-en_US/programs/games/gomoku/gomoku && kpack --nologo "../../../build-en_US/programs/games/gomoku/gomoku" )
( cd "$ROOT/programs/develop/mstate" && INCLUDE='../..' fasm -dlang=en_US mstate.asm ../../../build-en_US/programs/develop/mstate/mstate && kpack --nologo "../../../build-en_US/programs/develop/mstate/mstate" )
( cd "$ROOT/programs/media/volume" && fasm volume.asm ../../../build-en_US/programs/media/volume/volume && kpack --nologo "../../../build-en_US/programs/media/volume/volume" )
( cd "$ROOT/programs/games/sq_game" && INCLUDE='../..' fasm -dlang=en_US SQ_GAME.ASM ../../../build-en_US/programs/games/sq_game/SQ_GAME && kpack --nologo "../../../build-en_US/programs/games/sq_game/SQ_GAME" )
( cd "$ROOT/programs/demos/aclock" && fasm aclock.asm ../../../build-en_US/programs/demos/aclock/aclock && kpack --nologo "../../../build-en_US/programs/demos/aclock/aclock" )
( cd "$ROOT/programs/games/lines" && echo lang fix en_US > ../../../build-en_US/programs/games/lines/lang.inc )
( cd "$ROOT/programs/games/lines" && INCLUDE='../..;../../../build-en_US/programs/games/lines' fasm lines.asm ../../../build-en_US/programs/games/lines/lines && kpack --nologo "../../../build-en_US/programs/games/lines/lines" )
( cd "$ROOT/programs/system/apm" && fasm apm.asm ../../../build-en_US/programs/system/apm/apm && kpack --nologo "../../../build-en_US/programs/system/apm/apm" )
( cd "$ROOT/programs/games/MSquare" && echo lang fix en_US > ../../../build-en_US/programs/games/MSquare/lang.inc )
( cd "$ROOT/programs/games/MSquare" && INCLUDE='../..;../../../build-en_US/programs/games/MSquare' fasm MSquare.asm ../../../build-en_US/programs/games/MSquare/MSquare && kpack --nologo "../../../build-en_US/programs/games/MSquare/MSquare" )
( cd "$ROOT/programs/other/calc" && fasm calc.asm ../../../build-en_US/programs/other/calc/calc && kpack --nologo "../../../build-en_US/programs/other/calc/calc" )
( cd "$ROOT/programs/games/pipes" && echo lang fix en_US > ../../../build-en_US/programs/games/pipes/lang.inc )
( cd "$ROOT/programs/games/pipes" && INCLUDE='../..;../../../build-en_US/programs/games/pipes' fasm pipes.asm ../../../build-en_US/programs/games/pipes/pipes && kpack --nologo "../../../build-en_US/programs/games/pipes/pipes" )
( cd "$ROOT/programs/other/calcplus" && INCLUDE='../..' fasm -dlang=en_US calcplus.asm ../../../build-en_US/programs/other/calcplus/calcplus&& kpack --nologo "../../../build-en_US/programs/other/calcplus/calcplus" )
( cd "$ROOT/programs/games/pong" && echo lang fix en_US > ../../../build-en_US/programs/games/pong/lang.inc )
( cd "$ROOT/programs/games/pong" && INCLUDE='../..;../../../build-en_US/programs/games/pong' fasm pong.asm ../../../build-en_US/programs/games/pong/pong && kpack --nologo "../../../build-en_US/programs/games/pong/pong" )
( cd "$ROOT/programs/system/calendar" && echo lang fix en_US > ../../../build-en_US/programs/system/calendar/lang.inc )
( cd "$ROOT/programs/system/calendar" && INCLUDE='../..;../../../build-en_US/programs/system/calendar' fasm calendar.asm ../../../build-en_US/programs/system/calendar/calendar && kpack --nologo "../../../build-en_US/programs/system/calendar/calendar" )
( cd "$ROOT/programs/games/pong3" && fasm pong3.asm ../../../build-en_US/programs/games/pong3/pong3 && kpack --nologo "../../../build-en_US/programs/games/pong3/pong3" )
( cd "$ROOT/programs/system/colrdial" && fasm color_dialog.asm ../../../build-en_US/programs/system/colrdial/color_dialog && kpack --nologo "../../../build-en_US/programs/system/colrdial/color_dialog" )
( cd "$ROOT/programs/games/rsquare" && INCLUDE='../..' fasm -dlang=en_US rsquare.asm ../../../build-en_US/programs/games/rsquare/rsquare && kpack --nologo "../../../build-en_US/programs/games/rsquare/rsquare" )
( cd "$ROOT/programs/system/cropflat" && fasm cropflat.asm ../../../build-en_US/programs/system/cropflat/cropflat && kpack --nologo "../../../build-en_US/programs/system/cropflat/cropflat" )
( cd "$ROOT/programs/games/snake" && INCLUDE='../..' fasm -dlang=en_US snake.asm ../../../build-en_US/programs/games/snake/snake&& kpack --nologo "../../../build-en_US/programs/games/snake/snake" )
( cd "$ROOT/programs/system/cpu" && echo lang fix en_US > ../../../build-en_US/programs/system/cpu/lang.inc )
( cd "$ROOT/programs/system/cpu" && INCLUDE='../..;../../../build-en_US/programs/system/cpu' fasm cpu.asm ../../../build-en_US/programs/system/cpu/cpu && kpack --nologo "../../../build-en_US/programs/system/cpu/cpu" )
( cd "$ROOT/programs/games/sudoku" && echo lang fix en_US > ../../../build-en_US/programs/games/sudoku/lang.inc )
( cd "$ROOT/programs/games/sudoku" && INCLUDE='../..;../../../build-en_US/programs/games/sudoku' fasm sudoku.asm ../../../build-en_US/programs/games/sudoku/sudoku && kpack --nologo "../../../build-en_US/programs/games/sudoku/sudoku" )
( cd "$ROOT/programs/testing/cpuid" && echo lang fix en_US > ../../../build-en_US/programs/testing/cpuid/lang.inc )
( cd "$ROOT/programs/testing/cpuid" && INCLUDE='../..;../../../build-en_US/programs/testing/cpuid' fasm CPUID.ASM ../../../build-en_US/programs/testing/cpuid/CPUID -m70000&& kpack --nologo "../../../build-en_US/programs/testing/cpuid/CPUID" )
( cd "$ROOT/programs/games/sw" && echo lang fix en_US > ../../../build-en_US/programs/games/sw/lang.inc )
( cd "$ROOT/programs/games/sw" && INCLUDE='../..;../../../build-en_US/programs/games/sw' fasm sw.asm ../../../build-en_US/programs/games/sw/sw && kpack --nologo "../../../build-en_US/programs/games/sw/sw" )
( cd "$ROOT/programs/system/docpack" && INCLUDE='../..;../../../build-en_US/programs/system/docpack' fasm -dlang=en_US docpack.asm ../../../build-en_US/programs/system/docpack/docpack && kpack --nologo "../../../build-en_US/programs/system/docpack/docpack" )
( cd "$ROOT/programs/games/tanks" && echo lang fix en_US > ../../../build-en_US/programs/games/tanks/lang.inc )
( cd "$ROOT/programs/games/tanks" && INCLUDE='../..;../../../build-en_US/programs/games/tanks' fasm tanks.asm ../../../build-en_US/programs/games/tanks/tanks && kpack --nologo "../../../build-en_US/programs/games/tanks/tanks" )
( cd "$ROOT/skins/Leency/Shkvorka" && fasm "colors.dtp.asm" "../../../build-en_US/skins/Leency/Shkvorka/colors.dtp" )
( cd "$ROOT/skins/Leency/Shkvorka" && INCLUDE='../../../programs;../../../build-en_US/skins/Leency/Shkvorka' fasm "default.asm" "../../../build-en_US/skins/Leency/Shkvorka/Shkvorka.skn" && kpack --nologo "../../../build-en_US/skins/Leency/Shkvorka/Shkvorka.skn" )
( cd "$ROOT/programs/games/tetris" && echo lang fix en_US > ../../../build-en_US/programs/games/tetris/lang.inc )
( cd "$ROOT/programs/games/tetris" && INCLUDE='../..;../../../build-en_US/programs/games/tetris' fasm tetris.asm ../../../build-en_US/programs/games/tetris/tetris && kpack --nologo "../../../build-en_US/programs/games/tetris/tetris" )
( cd "$ROOT/programs/games/c4" && echo lang fix en_US > ../../../build-en_US/programs/games/c4/lang.inc )
( cd "$ROOT/programs/games/c4" && INCLUDE='../..;../../../build-en_US/programs/games/c4' fasm c4.asm ../../../build-en_US/programs/games/c4/c4 && kpack --nologo "../../../build-en_US/programs/games/c4/c4" )
( cd "$ROOT/programs/testing/disptest" && echo lang fix en_US > ../../../build-en_US/programs/testing/disptest/lang.inc )
( cd "$ROOT/programs/testing/disptest" && INCLUDE='../..;../../../build-en_US/programs/testing/disptest' fasm disptest.ASM ../../../build-en_US/programs/testing/disptest/disptest && kpack --nologo "../../../build-en_US/programs/testing/disptest/disptest" )
( cd "$ROOT/programs/fs/kfar/kfar_arc" && echo lang fix en_US > ../../../../build-en_US/programs/fs/kfar/kfar_arc/lang.inc )
( cd "$ROOT/programs/fs/kfar/kfar_arc" && INCLUDE='../../..;../../../../build-en_US/programs/fs/kfar/kfar_arc' fasm kfar_arc.asm ../../../../build-en_US/programs/fs/kfar/kfar_arc/kfar_arc.obj && kpack --nologo "../../../../build-en_US/programs/fs/kfar/kfar_arc/kfar_arc.obj" )
( cd "$ROOT/programs/system/end/light" && echo lang fix en_US > ../../../../build-en_US/programs/system/end/light/lang.inc )
( cd "$ROOT/programs/system/end/light" && INCLUDE='../../..;../../../../build-en_US/programs/system/end/light' fasm end.asm ../../../../build-en_US/programs/system/end/light/end && kpack --nologo "../../../../build-en_US/programs/system/end/light/end" )
( cd "$ROOT/programs/develop/libraries/box_lib" && fasm box_lib.asm ../../../../build-en_US/programs/develop/libraries/box_lib/box_lib.obj && kpack --nologo "../../../../build-en_US/programs/develop/libraries/box_lib/box_lib.obj" )
( cd "$ROOT/programs/system/eskin" && fasm eskin.asm ../../../build-en_US/programs/system/eskin/eskin && kpack --nologo "../../../build-en_US/programs/system/eskin/eskin" )
( cd "$ROOT/programs/develop/libraries/buf2d" && fasm buf2d.asm ../../../../build-en_US/programs/develop/libraries/buf2d/buf2d.obj && kpack --nologo "../../../../build-en_US/programs/develop/libraries/buf2d/buf2d.obj" )
( cd "$ROOT/programs/system/gmon" && INCLUDE='../..' fasm -dlang=en_US gmon.asm ../../../build-en_US/programs/system/gmon/gmon && kpack --nologo "../../../build-en_US/programs/system/gmon/gmon" )
( cd "$ROOT/programs/develop/libraries/console_coff" && fasm console.asm ../../../../build-en_US/programs/develop/libraries/console_coff/console.obj && kpack --nologo "../../../../build-en_US/programs/develop/libraries/console_coff/console.obj" )
( cd "$ROOT/programs/media/zsea/plugins/png" && fasm cnv_png.asm ../../../../../build-en_US/programs/media/zsea/plugins/png/cnv_png.obj && kpack --nologo "../../../../../build-en_US/programs/media/zsea/plugins/png/cnv_png.obj" )
( cd "$ROOT/programs/system/hdd_info" && echo lang fix en_US > ../../../build-en_US/programs/system/hdd_info/lang.inc )
( cd "$ROOT/programs/system/hdd_info" && INCLUDE='../..;../../../build-en_US/programs/system/hdd_info' fasm hdd_info.asm ../../../build-en_US/programs/system/hdd_info/hdd_info && kpack --nologo "../../../build-en_US/programs/system/hdd_info/hdd_info" )
( cd "$ROOT/programs/testing/kbd" && echo lang fix en_US > ../../../build-en_US/programs/testing/kbd/lang.inc )
( cd "$ROOT/programs/testing/kbd" && INCLUDE='../..;../../../build-en_US/programs/testing/kbd' fasm kbd.ASM ../../../build-en_US/programs/testing/kbd/kbd && kpack --nologo "../../../build-en_US/programs/testing/kbd/kbd" )
( cd "$ROOT/programs/develop/libraries/dll" && fasm dll.asm ../../../../build-en_US/programs/develop/libraries/dll/dll.obj && kpack --nologo "../../../../build-en_US/programs/develop/libraries/dll/dll.obj" )
( cd "$ROOT/programs/other/kpack" && fasm kpack.asm ../../../build-en_US/programs/other/kpack/kpack && kpack --nologo "../../../build-en_US/programs/other/kpack/kpack" )
( cd "$ROOT/programs/develop/libraries/http" && fasm http.asm ../../../../build-en_US/programs/develop/libraries/http/http.obj && kpack --nologo "../../../../build-en_US/programs/develop/libraries/http/http.obj" )
( cd "$ROOT/programs/develop/libraries/libcrash" && INCLUDE='../../..' fasm libcrash.asm ../../../../build-en_US/programs/develop/libraries/libcrash/libcrash.obj && kpack --nologo "../../../../build-en_US/programs/develop/libraries/libcrash/libcrash.obj" )
( cd "$ROOT/programs/system/launcher" && fasm launcher.asm ../../../build-en_US/programs/system/launcher/launcher && kpack --nologo "../../../build-en_US/programs/system/launcher/launcher" )
( cd "$ROOT/programs/develop/libraries/libs-dev/libgfx" && fasm libgfx.asm ../../../../../build-en_US/programs/develop/libraries/libs-dev/libgfx/libgfx.obj && kpack --nologo "../../../../../build-en_US/programs/develop/libraries/libs-dev/libgfx/libgfx.obj" )
( cd "$ROOT/programs/system/loaddrv" && fasm loaddrv.asm ../../../build-en_US/programs/system/loaddrv/loaddrv && kpack --nologo "../../../build-en_US/programs/system/loaddrv/loaddrv" )
( cd "$ROOT/programs/system/magnify" && INCLUDE='../..' fasm -dlang=en_US magnify.asm ../../../build-en_US/programs/system/magnify/magnify&& kpack --nologo "../../../build-en_US/programs/system/magnify/magnify" )
( cd "$ROOT/programs/develop/libraries/libs-dev/libimg" && INCLUDE='../../../..;../../../../../programs//develop/libraries/libs-dev/libio' fasm -m 32768 libimg.asm ../../../../../build-en_US/programs/develop/libraries/libs-dev/libimg/libimg.obj && kpack --nologo "../../../../../build-en_US/programs/develop/libraries/libs-dev/libimg/libimg.obj" )
( cd "$ROOT/programs/other/madmouse" && fasm madmouse.asm ../../../build-en_US/programs/other/madmouse/madmouse && kpack --nologo "../../../build-en_US/programs/other/madmouse/madmouse" )
( cd "$ROOT/programs/develop/libraries/libs-dev/libini" && fasm libini.asm ../../../../../build-en_US/programs/develop/libraries/libs-dev/libini/libini.obj && kpack --nologo "../../../../../build-en_US/programs/develop/libraries/libs-dev/libini/libini.obj" )
( cd "$ROOT/programs/develop/libraries/libs-dev/libio" && fasm libio.asm ../../../../../build-en_US/programs/develop/libraries/libs-dev/libio/libio.obj && kpack --nologo "../../../../../build-en_US/programs/develop/libraries/libs-dev/libio/libio.obj" )
( cd "$ROOT/programs/system/mousemul" && echo lang fix en_US > ../../../build-en_US/programs/system/mousemul/lang.inc )
( cd "$ROOT/programs/system/mousemul" && INCLUDE='../..;../../../build-en_US/programs/system/mousemul' fasm mousemul.asm ../../../build-en_US/programs/system/mousemul/mousemul && kpack --nologo "../../../build-en_US/programs/system/mousemul/mousemul" )
( cd "$ROOT/programs/develop/libraries/msgbox" && fasm msgbox.asm ../../../../build-en_US/programs/develop/libraries/msgbox/msgbox.obj && kpack --nologo "../../../../build-en_US/programs/develop/libraries/msgbox/msgbox.obj" )
( cd "$ROOT/programs/other/mousepos" && fasm -dlang=en_US mousepos.asm ../../../build-en_US/programs/other/mousepos/mousepos && kpack --nologo "../../../build-en_US/programs/other/mousepos/mousepos" )
( cd "$ROOT/programs/develop/libraries/network" && fasm network.asm ../../../../build-en_US/programs/develop/libraries/network/network.obj && kpack --nologo "../../../../build-en_US/programs/develop/libraries/network/network.obj" )
( cd "$ROOT/programs/testing/pcidev" && echo lang fix en_US > ../../../build-en_US/programs/testing/pcidev/lang.inc )
( cd "$ROOT/programs/testing/pcidev" && INCLUDE='../..;../../../build-en_US/programs/testing/pcidev' fasm PCIDEV.ASM ../../../build-en_US/programs/testing/pcidev/PCIDEV && kpack --nologo "../../../build-en_US/programs/testing/pcidev/PCIDEV" )
( cd "$ROOT/programs/develop/libraries/proc_lib" && fasm proc_lib.asm ../../../../build-en_US/programs/develop/libraries/proc_lib/proc_lib.obj && kpack --nologo "../../../../build-en_US/programs/develop/libraries/proc_lib/proc_lib.obj" )
( cd "$ROOT/programs/system/rdsave" && echo lang fix en_US > ../../../build-en_US/programs/system/rdsave/lang.inc )
( cd "$ROOT/programs/system/rdsave" && INCLUDE='../..;../../../build-en_US/programs/system/rdsave' fasm rdsave.asm ../../../build-en_US/programs/system/rdsave/rdsave && kpack --nologo "../../../build-en_US/programs/system/rdsave/rdsave" )
( cd "$ROOT/programs/develop/libraries/fontRasterWorks_unicode" && fasm RasterWorks.asm ../../../../build-en_US/programs/develop/libraries/fontRasterWorks_unicode/RasterWorks.obj && kpack --nologo "../../../../build-en_US/programs/develop/libraries/fontRasterWorks_unicode/RasterWorks.obj" )
( cd "$ROOT/programs/other/rtfread" && fasm rtfread.asm ../../../build-en_US/programs/other/rtfread/rtfread && kpack --nologo "../../../build-en_US/programs/other/rtfread/rtfread" )
( cd "$ROOT/programs/develop/libraries/sorter" && fasm sort.asm ../../../../build-en_US/programs/develop/libraries/sorter/sort.obj && kpack --nologo "../../../../build-en_US/programs/develop/libraries/sorter/sort.obj" )
( cd "$ROOT/programs/system/searchap" && fasm searchap.asm ../../../build-en_US/programs/system/searchap/searchap && kpack --nologo "../../../build-en_US/programs/system/searchap/searchap" )
( cd "$ROOT/programs/develop/libraries/TinyGL/asm_fork" && fasm tinygl.asm ../../../../../build-en_US/programs/develop/libraries/TinyGL/asm_fork/tinygl.obj && kpack --nologo "../../../../../build-en_US/programs/develop/libraries/TinyGL/asm_fork/tinygl.obj" )
( cd "$ROOT/programs/media/animage" && fasm animage.asm ../../../build-en_US/programs/media/animage/animage && kpack --nologo "../../../build-en_US/programs/media/animage/animage" )
( cd "$ROOT/programs/media/scrshoot" && echo lang fix en_US > ../../../build-en_US/programs/media/scrshoot/lang.inc )
( cd "$ROOT/programs/media/scrshoot" && INCLUDE='../..;../../../build-en_US/programs/media/scrshoot' fasm scrshoot.asm ../../../build-en_US/programs/media/scrshoot/scrshoot && kpack --nologo "../../../build-en_US/programs/media/scrshoot/scrshoot" )
( cd "$ROOT/programs/media/FillScr" && fasm fillscr.asm ../../../build-en_US/programs/media/FillScr/fillscr && kpack --nologo "../../../build-en_US/programs/media/FillScr/fillscr" )
( cd "$ROOT/programs/system/setup" && fasm setup.asm ../../../build-en_US/programs/system/setup/setup && kpack --nologo "../../../build-en_US/programs/system/setup/setup" )
( cd "$ROOT/programs/media/kiv" && INCLUDE='../..;../../../programs//develop/libraries/libs-dev/libimg' fasm kiv.asm ../../../build-en_US/programs/media/kiv/kiv && kpack --nologo "../../../build-en_US/programs/media/kiv/kiv" )
( cd "$ROOT/programs/system/skincfg" && echo lang fix en_US > ../../../build-en_US/programs/system/skincfg/lang.inc )
( cd "$ROOT/programs/system/skincfg" && INCLUDE='../..;../../../build-en_US/programs/system/skincfg' fasm skincfg.asm ../../../build-en_US/programs/system/skincfg/skincfg && kpack --nologo "../../../build-en_US/programs/system/skincfg/skincfg" )
( cd "$ROOT/programs/media/listplay" && fasm listplay.asm ../../../build-en_US/programs/media/listplay/listplay && kpack --nologo "../../../build-en_US/programs/media/listplay/listplay" )
( cd "$ROOT/programs/system/terminal" && fasm terminal.asm ../../../build-en_US/programs/system/terminal/terminal && kpack --nologo "../../../build-en_US/programs/system/terminal/terminal" )
( cd "$ROOT/programs/media/midamp" && echo lang fix en_US > ../../../build-en_US/programs/media/midamp/lang.inc )
( cd "$ROOT/programs/media/midamp" && INCLUDE='../..;../../../build-en_US/programs/media/midamp' fasm midamp.asm ../../../build-en_US/programs/media/midamp/midamp && kpack --nologo "../../../build-en_US/programs/media/midamp/midamp" )
( cd "$ROOT/programs/media/mp3info" && fasm mp3info.asm ../../../build-en_US/programs/media/mp3info/mp3info && kpack --nologo "../../../build-en_US/programs/media/mp3info/mp3info" )
( cd "$ROOT/data/en_US" && cp welcome.htm ../../build-en_US/data/en_US/welcome.htm.kpack&& kpack --nologo "../../build-en_US/data/en_US/welcome.htm.kpack" )
( cd "$ROOT/programs/testing/protection" && echo lang fix en_US > ../../../build-en_US/programs/testing/protection/lang.inc )
( cd "$ROOT/programs/testing/protection" && INCLUDE='../..;../../../build-en_US/programs/testing/protection' fasm test.asm ../../../build-en_US/programs/testing/protection/test && kpack --nologo "../../../build-en_US/programs/testing/protection/test" )
( cd "$ROOT/programs/media/palitra" && fasm palitra.asm ../../../build-en_US/programs/media/palitra/palitra && kpack --nologo "../../../build-en_US/programs/media/palitra/palitra" )
( cd "$ROOT/programs/develop/tinypad" && echo lang fix en_US > ../../../build-en_US/programs/develop/tinypad/lang.inc )
( cd "$ROOT/programs/develop/tinypad" && INCLUDE='../..;../../../build-en_US/programs/develop/tinypad' fasm tinypad.asm ../../../build-en_US/programs/develop/tinypad/tinypad && kpack --nologo "../../../build-en_US/programs/develop/tinypad/tinypad" )
( cd "$ROOT/programs/media/piano" && INCLUDE='../..' fasm keymap.asm ../../../build-en_US/programs/media/piano/piano.map )
( cd "$ROOT/programs/media/piano" && INCLUDE='../..' fasm -dlang=en_US piano.asm ../../../build-en_US/programs/media/piano/piano&& kpack --nologo "../../../build-en_US/programs/media/piano/piano" )
( cd "$ROOT/programs/system/tinfo" && echo lang fix en_US > ../../../build-en_US/programs/system/tinfo/lang.inc )
( cd "$ROOT/programs/system/tinfo" && INCLUDE='../..;../../../build-en_US/programs/system/tinfo' fasm tinfo.asm ../../../build-en_US/programs/system/tinfo/tinfo && kpack --nologo "../../../build-en_US/programs/system/tinfo/tinfo" )
( cd "$ROOT/programs/media/startmus" && fasm STARTMUS.ASM ../../../build-en_US/programs/media/startmus/STARTMUS && kpack --nologo "../../../build-en_US/programs/media/startmus/STARTMUS" )
( cd "$ROOT/programs/other/Timer" && echo lang fix en_US > ../../../build-en_US/programs/other/Timer/lang.inc )
( cd "$ROOT/programs/other/Timer" && INCLUDE='../..;../../../build-en_US/programs/other/Timer' fasm Timer.asm ../../../build-en_US/programs/other/Timer/Timer && kpack --nologo "../../../build-en_US/programs/other/Timer/Timer" )
( cd "$ROOT/programs/network/ping" && fasm ping.asm ../../../build-en_US/programs/network/ping/ping && kpack --nologo "../../../build-en_US/programs/network/ping/ping" )
( cd "$ROOT/programs/network/netcfg" && fasm netcfg.asm ../../../build-en_US/programs/network/netcfg/netcfg && kpack --nologo "../../../build-en_US/programs/network/netcfg/netcfg" )
( cd "$ROOT/programs/fs/unz" && echo lang fix en_US > ../../../build-en_US/programs/fs/unz/lang.inc )
( cd "$ROOT/programs/fs/unz" && INCLUDE='../..;../../../build-en_US/programs/fs/unz' fasm unz.asm ../../../build-en_US/programs/fs/unz/unz && kpack --nologo "../../../build-en_US/programs/fs/unz/unz" )
( cd "$ROOT/programs/network/netstat" && fasm netstat.asm ../../../build-en_US/programs/network/netstat/netstat && kpack --nologo "../../../build-en_US/programs/network/netstat/netstat" )
( cd "$ROOT/programs/system/zkey" && fasm ZKEY.ASM ../../../build-en_US/programs/system/zkey/ZKEY && kpack --nologo "../../../build-en_US/programs/system/zkey/ZKEY" )
( cd "$ROOT/programs/network/netsurf" && fasm netsurf.asm ../../../build-en_US/programs/network/netsurf/netsurf && kpack --nologo "../../../build-en_US/programs/network/netsurf/netsurf" )
( cd "$ROOT/programs/demos/3dwav" && fasm 3dwav.asm ../../../build-en_US/programs/demos/3dwav/3dwav && kpack --nologo "../../../build-en_US/programs/demos/3dwav/3dwav" )
( cd "$ROOT/programs/network/nslookup" && fasm nslookup.asm ../../../build-en_US/programs/network/nslookup/nslookup && kpack --nologo "../../../build-en_US/programs/network/nslookup/nslookup" )
( cd "$ROOT/programs/demos/crownscr" && echo lang fix en_US > ../../../build-en_US/programs/demos/crownscr/lang.inc )
( cd "$ROOT/programs/demos/crownscr" && INCLUDE='../..;../../../build-en_US/programs/demos/crownscr' fasm crownscr.asm ../../../build-en_US/programs/demos/crownscr/crownscr && kpack --nologo "../../../build-en_US/programs/demos/crownscr/crownscr" )
( cd "$ROOT/programs/network/pasta" && fasm pasta.asm ../../../build-en_US/programs/network/pasta/pasta && kpack --nologo "../../../build-en_US/programs/network/pasta/pasta" )
( cd "$ROOT/programs/demos/3dcube2" && fasm 3DCUBE2.ASM ../../../build-en_US/programs/demos/3dcube2/3DCUBE2 && kpack --nologo "../../../build-en_US/programs/demos/3dcube2/3DCUBE2" )
( cd "$ROOT/programs/network/synergyc" && fasm synergyc.asm ../../../build-en_US/programs/network/synergyc/synergyc && kpack --nologo "../../../build-en_US/programs/network/synergyc/synergyc" )
( cd "$ROOT/programs/network/sntp" && fasm sntp.asm ../../../build-en_US/programs/network/sntp/sntp && kpack --nologo "../../../build-en_US/programs/network/sntp/sntp" )
( cd "$ROOT/programs/demos/free3d04" && echo lang fix en_US > ../../../build-en_US/programs/demos/free3d04/lang.inc )
( cd "$ROOT/programs/demos/free3d04" && INCLUDE='../..;../../../build-en_US/programs/demos/free3d04' fasm free3d04.asm ../../../build-en_US/programs/demos/free3d04/free3d04 && kpack --nologo "../../../build-en_US/programs/demos/free3d04/free3d04" )
( cd "$ROOT/programs/develop/libraries/TinyGL/asm_fork/examples" && fasm gears.asm ../../../../../../build-en_US/programs/develop/libraries/TinyGL/asm_fork/examples/gears && kpack --nologo "../../../../../../build-en_US/programs/develop/libraries/TinyGL/asm_fork/examples/gears" )
( cd "$ROOT/programs/network/telnet" && fasm telnet.asm ../../../build-en_US/programs/network/telnet/telnet && kpack --nologo "../../../build-en_US/programs/network/telnet/telnet" )
( cd "$ROOT/programs/network/zeroconf" && fasm zeroconf.asm ../../../build-en_US/programs/network/zeroconf/zeroconf && kpack --nologo "../../../build-en_US/programs/network/zeroconf/zeroconf" )
( cd "$ROOT/programs/network/ftpd" && fasm ftpd.asm ../../../build-en_US/programs/network/ftpd/ftpd && kpack --nologo "../../../build-en_US/programs/network/ftpd/ftpd" )
( cd "$ROOT/programs/network/tftpc" && fasm tftpc.asm ../../../build-en_US/programs/network/tftpc/tftpc && kpack --nologo "../../../build-en_US/programs/network/tftpc/tftpc" )
( cd "$ROOT/programs/network/ircc" && fasm ircc.asm ../../../build-en_US/programs/network/ircc/ircc && kpack --nologo "../../../build-en_US/programs/network/ircc/ircc" )
( cd "$ROOT/programs/network/httpget" && fasm httpget.asm ../../../build-en_US/programs/network/httpget/httpget && kpack --nologo "../../../build-en_US/programs/network/httpget/httpget" )
( cd "$ROOT/programs/network/vncc" && fasm -m 32768 vncc.asm ../../../build-en_US/programs/network/vncc/vncc && kpack --nologo "../../../build-en_US/programs/network/vncc/vncc" )
( cd "$ROOT/drivers/video" && fasm rdc.asm ../../build-en_US/drivers/video/rdc.sys && kpack --nologo "../../build-en_US/drivers/video/rdc.sys" )
( cd "$ROOT/drivers/video" && fasm vidintel.asm ../../build-en_US/drivers/video/vidintel.sys && kpack --nologo "../../build-en_US/drivers/video/vidintel.sys" )
( cd "$ROOT/programs/demos/ray" && echo lang fix en_US > ../../../build-en_US/programs/demos/ray/lang.inc )
( cd "$ROOT/programs/demos/ray" && INCLUDE='../..;../../../build-en_US/programs/demos/ray' fasm ray.asm ../../../build-en_US/programs/demos/ray/ray && kpack --nologo "../../../build-en_US/programs/demos/ray/ray" )
( cd "$ROOT/drivers/ethernet" && fasm 3c59x.asm ../../build-en_US/drivers/ethernet/3c59x.sys && kpack --nologo "../../build-en_US/drivers/ethernet/3c59x.sys" )
( cd "$ROOT/programs/demos/view3ds" && fasm view3ds.asm ../../../build-en_US/programs/demos/view3ds/view3ds && kpack --nologo "../../../build-en_US/programs/demos/view3ds/view3ds" )
( cd "$ROOT/drivers/ethernet" && fasm R6040.asm ../../build-en_US/drivers/ethernet/R6040.sys && kpack --nologo "../../build-en_US/drivers/ethernet/R6040.sys" )
( cd "$ROOT/drivers/ethernet" && fasm RTL8029.asm ../../build-en_US/drivers/ethernet/RTL8029.sys && kpack --nologo "../../build-en_US/drivers/ethernet/RTL8029.sys" )
( cd "$ROOT/drivers/ethernet" && fasm RTL8139.asm ../../build-en_US/drivers/ethernet/RTL8139.sys && kpack --nologo "../../build-en_US/drivers/ethernet/RTL8139.sys" )
( cd "$ROOT/programs/demos/bcdclk" && echo lang fix en_US > ../../../build-en_US/programs/demos/bcdclk/lang.inc )
( cd "$ROOT/programs/demos/bcdclk" && INCLUDE='../..;../../../build-en_US/programs/demos/bcdclk' fasm bcdclk.asm ../../../build-en_US/programs/demos/bcdclk/bcdclk && kpack --nologo "../../../build-en_US/programs/demos/bcdclk/bcdclk" )
( cd "$ROOT/drivers/ethernet" && fasm RTL8169.asm ../../build-en_US/drivers/ethernet/RTL8169.sys && kpack --nologo "../../build-en_US/drivers/ethernet/RTL8169.sys" )
( cd "$ROOT/programs/demos/buddhabrot" && fasm buddhabrot.asm ../../../build-en_US/programs/demos/buddhabrot/buddhabrot && kpack --nologo "../../../build-en_US/programs/demos/buddhabrot/buddhabrot" )
( cd "$ROOT/drivers/ethernet" && fasm ar81xx.asm ../../build-en_US/drivers/ethernet/ar81xx.sys && kpack --nologo "../../build-en_US/drivers/ethernet/ar81xx.sys" )
( cd "$ROOT/drivers/ethernet" && fasm dec21x4x.asm ../../build-en_US/drivers/ethernet/dec21x4x.sys && kpack --nologo "../../build-en_US/drivers/ethernet/dec21x4x.sys" )
( cd "$ROOT/drivers/ethernet" && fasm forcedeth.asm ../../build-en_US/drivers/ethernet/forcedeth.sys && kpack --nologo "../../build-en_US/drivers/ethernet/forcedeth.sys" )
( cd "$ROOT/drivers/ethernet" && fasm i8254x.asm ../../build-en_US/drivers/ethernet/i8254x.sys && kpack --nologo "../../build-en_US/drivers/ethernet/i8254x.sys" )
( cd "$ROOT/drivers/ethernet" && fasm i8255x.asm ../../build-en_US/drivers/ethernet/i8255x.sys && kpack --nologo "../../build-en_US/drivers/ethernet/i8255x.sys" )
( cd "$ROOT/programs/demos/eyes" && echo lang fix en_US > ../../../build-en_US/programs/demos/eyes/lang.inc )
( cd "$ROOT/programs/demos/eyes" && INCLUDE='../..;../../../build-en_US/programs/demos/eyes' fasm eyes.asm ../../../build-en_US/programs/demos/eyes/eyes && kpack --nologo "../../../build-en_US/programs/demos/eyes/eyes" )
( cd "$ROOT/drivers/ethernet" && fasm mtd80x.asm ../../build-en_US/drivers/ethernet/mtd80x.sys && kpack --nologo "../../build-en_US/drivers/ethernet/mtd80x.sys" )
( cd "$ROOT/drivers/ethernet" && fasm pcnet32.asm ../../build-en_US/drivers/ethernet/pcnet32.sys && kpack --nologo "../../build-en_US/drivers/ethernet/pcnet32.sys" )
( cd "$ROOT/drivers/ethernet" && fasm rhine.asm ../../build-en_US/drivers/ethernet/rhine.sys && kpack --nologo "../../build-en_US/drivers/ethernet/rhine.sys" )
( cd "$ROOT/programs/demos/firework" && fasm firework.asm ../../../build-en_US/programs/demos/firework/firework && kpack --nologo "../../../build-en_US/programs/demos/firework/firework" )
( cd "$ROOT/drivers/ethernet" && fasm sis900.asm ../../build-en_US/drivers/ethernet/sis900.sys && kpack --nologo "../../build-en_US/drivers/ethernet/sis900.sys" )
( cd "$ROOT/programs/demos/movback" && fasm movback.asm ../../../build-en_US/programs/demos/movback/movback && kpack --nologo "../../../build-en_US/programs/demos/movback/movback" )
( cd "$ROOT/drivers/usb" && fasm ehci.asm ../../build-en_US/drivers/usb/ehci.sys && kpack --nologo "../../build-en_US/drivers/usb/ehci.sys" )
( cd "$ROOT/drivers/usb" && fasm ohci.asm ../../build-en_US/drivers/usb/ohci.sys && kpack --nologo "../../build-en_US/drivers/usb/ohci.sys" )
( cd "$ROOT/drivers/usb" && fasm uhci.asm ../../build-en_US/drivers/usb/uhci.sys && kpack --nologo "../../build-en_US/drivers/usb/uhci.sys" )
( cd "$ROOT/programs/demos/plasma" && echo lang fix en_US > ../../../build-en_US/programs/demos/plasma/lang.inc )
( cd "$ROOT/programs/demos/plasma" && INCLUDE='../..;../../../build-en_US/programs/demos/plasma' fasm plasma.asm ../../../build-en_US/programs/demos/plasma/plasma && kpack --nologo "../../../build-en_US/programs/demos/plasma/plasma" )
( cd "$ROOT/drivers/usb" && fasm usbstor.asm ../../build-en_US/drivers/usb/usbstor.sys && kpack --nologo "../../build-en_US/drivers/usb/usbstor.sys" )
( cd "$ROOT/drivers/usb/xhci" && fasm xhci.asm ../../../build-en_US/drivers/usb/xhci/xhci.sys && kpack --nologo "../../../build-en_US/drivers/usb/xhci/xhci.sys" )
( cd "$ROOT/programs/demos/spiral" && INCLUDE='../..' fasm spiral.asm ../../../build-en_US/programs/demos/spiral/spiral && kpack --nologo "../../../build-en_US/programs/demos/spiral/spiral" )
( cd "$ROOT/drivers/usb/usbhid" && fasm usbhid.asm ../../../build-en_US/drivers/usb/usbhid/usbhid.sys && kpack --nologo "../../../build-en_US/drivers/usb/usbhid/usbhid.sys" )
( cd "$ROOT/kernel/trunk/bootloader" && echo lang fix en_US > ../../../build-en_US/kernel/trunk/bootloader/lang.inc )
( cd "$ROOT/kernel/trunk/bootloader" && INCLUDE='../../../programs;../../../build-en_US/kernel/trunk/bootloader' fasm boot_fat12.asm ../../../build-en_US/kernel/trunk/bootloader/boot_fat12.bin )
( cd "$ROOT/programs/demos/tinyfrac" && echo lang fix en_US > ../../../build-en_US/programs/demos/tinyfrac/lang.inc )
( cd "$ROOT/programs/demos/tinyfrac" && INCLUDE='../..;../../../build-en_US/programs/demos/tinyfrac' fasm tinyfrac.asm ../../../build-en_US/programs/demos/tinyfrac/tinyfrac && kpack --nologo "../../../build-en_US/programs/demos/tinyfrac/tinyfrac" )
( cd "$ROOT/drivers/usb/usbftdi" && fasm usbftdi.asm ../../../build-en_US/drivers/usb/usbftdi/usbftdi.sys && kpack --nologo "../../../build-en_US/drivers/usb/usbftdi/usbftdi.sys" )
( cd "$ROOT/drivers/usb/usbnet" && fasm usbcdc.asm ../../../build-en_US/drivers/usb/usbnet/usbcdc.sys && kpack --nologo "../../../build-en_US/drivers/usb/usbnet/usbcdc.sys" )
( cd "$ROOT/programs/demos/trantest" && echo lang fix en_US > ../../../build-en_US/programs/demos/trantest/lang.inc )
( cd "$ROOT/programs/demos/trantest" && INCLUDE='../..;../../../build-en_US/programs/demos/trantest' fasm trantest.asm ../../../build-en_US/programs/demos/trantest/trantest && kpack --nologo "../../../build-en_US/programs/demos/trantest/trantest" )
( cd "$ROOT/drivers/usb/usbnet" && fasm usbrndis.asm ../../../build-en_US/drivers/usb/usbnet/usbrndis.sys && kpack --nologo "../../../build-en_US/drivers/usb/usbnet/usbrndis.sys" )
( cd "$ROOT/programs/network/ftpc" && fasm ftpc.asm ../../../build-en_US/programs/network/ftpc/ftpc && kpack --nologo "../../../build-en_US/programs/network/ftpc/ftpc" )
( cd "$ROOT/programs/demos/tube" && fasm tube.asm ../../../build-en_US/programs/demos/tube/tube && kpack --nologo "../../../build-en_US/programs/demos/tube/tube" )
( cd "$ROOT/drivers/serial" && fasm serial.asm ../../build-en_US/drivers/serial/serial.sys && kpack --nologo "../../build-en_US/drivers/serial/serial.sys" )
( cd "$ROOT/programs/demos/unvwater" && INCLUDE='../..' fasm -dlang=en_US unvwater.asm ../../../build-en_US/programs/demos/unvwater/unvwater && kpack --nologo "../../../build-en_US/programs/demos/unvwater/unvwater" )
( cd "$ROOT/drivers/mouse" && fasm commouse.asm ../../build-en_US/drivers/mouse/commouse.sys && kpack --nologo "../../build-en_US/drivers/mouse/commouse.sys" )
( cd "$ROOT/programs/demos/web" && fasm web.asm ../../../build-en_US/programs/demos/web/web && kpack --nologo "../../../build-en_US/programs/demos/web/web" )
( cd "$ROOT/drivers/mouse/ps2mouse4d" && fasm ps2mouse.asm ../../../build-en_US/drivers/mouse/ps2mouse4d/ps2mouse.sys && kpack --nologo "../../../build-en_US/drivers/mouse/ps2mouse4d/ps2mouse.sys" )
( cd "$ROOT/programs/demos/zeroline" && fasm zeroline.asm ../../../build-en_US/programs/demos/zeroline/zeroline && kpack --nologo "../../../build-en_US/programs/demos/zeroline/zeroline" )
( cd "$ROOT/drivers/disk" && fasm tmpdisk.asm ../../build-en_US/drivers/disk/tmpdisk.sys && kpack --nologo "../../build-en_US/drivers/disk/tmpdisk.sys" )
( cd "$ROOT/drivers/disk" && fasm virt_disk.asm ../../build-en_US/drivers/disk/virt_disk.sys && kpack --nologo "../../build-en_US/drivers/disk/virt_disk.sys" )
( cd "$ROOT/programs/system/taskbar" && cp KEYMAP.KEY ../../../build-en_US/programs/system/taskbar/keymap.key.kpack&& kpack --nologo "../../../build-en_US/programs/system/taskbar/keymap.key.kpack" )
( cd "$ROOT/programs/system/board" && echo lang fix en_US > ../../../build-en_US/programs/system/board/lang.inc )
( cd "$ROOT/programs/system/board" && INCLUDE='../..;../../../build-en_US/programs/system/board' fasm board.asm ../../../build-en_US/programs/system/board/board && kpack --nologo "../../../build-en_US/programs/system/board/board" )
( cd "$ROOT/drivers/audio/intel_hda" && fasm hdaudio.asm ../../../build-en_US/drivers/audio/intel_hda/hdaudio.sys && kpack --nologo "../../../build-en_US/drivers/audio/intel_hda/hdaudio.sys" )
( cd "$ROOT/programs/system/taskbar" && echo lang fix en_US > ../../../build-en_US/programs/system/taskbar/lang.inc )
( cd "$ROOT/programs/system/taskbar" && INCLUDE='../..;../../../build-en_US/programs/system/taskbar' fasm TASKBAR.ASM ../../../build-en_US/programs/system/taskbar/TASKBAR && kpack --nologo "../../../build-en_US/programs/system/taskbar/TASKBAR" )
( cd "$ROOT/programs/system/dbgboard" && fasm dbgboard.asm ../../../build-en_US/programs/system/dbgboard/dbgboard && kpack --nologo "../../../build-en_US/programs/system/dbgboard/dbgboard" )
( cd "$ROOT/drivers/audio/sb16" && fasm sb16.asm ../../../build-en_US/drivers/audio/sb16/sb16.sys && kpack --nologo "../../../build-en_US/drivers/audio/sb16/sb16.sys" )
( cd "$ROOT/drivers/usb/usbother" && fasm usbother.asm ../../../build-en_US/drivers/usb/usbother/usbother.sys && kpack --nologo "../../../build-en_US/drivers/usb/usbother/usbother.sys" )
( cd "$ROOT/programs/develop/charsets" && INCLUDE='../..' fasm -dlang=en_US charsets.asm ../../../build-en_US/programs/develop/charsets/charsets&& kpack --nologo "../../../build-en_US/programs/develop/charsets/charsets" )
( cd "$ROOT/drivers/usb/usbother" && fasm usbdrv.asm ../../../build-en_US/drivers/usb/usbother/usbdrv.dat  )
( cd "$ROOT/drivers/audio" && fasm ac97.asm ../../build-en_US/drivers/audio/ac97.sys && kpack --nologo "../../build-en_US/drivers/audio/ac97.sys" )
( cd "$ROOT/drivers/audio" && fasm cmi8738.asm ../../build-en_US/drivers/audio/cmi8738.sys && kpack --nologo "../../build-en_US/drivers/audio/cmi8738.sys" )
( cd "$ROOT/programs/develop/cObj" && echo lang fix en_US > ../../../build-en_US/programs/develop/cObj/lang.inc )
( cd "$ROOT/programs/develop/cObj" && INCLUDE='../..;../../../build-en_US/programs/develop/cObj' fasm cObj.asm ../../../build-en_US/programs/develop/cObj/cObj && kpack --nologo "../../../build-en_US/programs/develop/cObj/cObj" )
( cd "$ROOT/drivers/audio" && fasm emu10k1x.asm ../../build-en_US/drivers/audio/emu10k1x.sys && kpack --nologo "../../build-en_US/drivers/audio/emu10k1x.sys" )
( cd "$ROOT/drivers/audio" && fasm es1371.asm ../../build-en_US/drivers/audio/es1371.sys && kpack --nologo "../../build-en_US/drivers/audio/es1371.sys" )
( cd "$ROOT/drivers/audio" && fasm fm801.asm ../../build-en_US/drivers/audio/fm801.sys && kpack --nologo "../../build-en_US/drivers/audio/fm801.sys" )
( cd "$ROOT/programs/develop/entropyview" && fasm entropyview.asm ../../../build-en_US/programs/develop/entropyview/entropyview && kpack --nologo "../../../build-en_US/programs/develop/entropyview/entropyview" )
( cd "$ROOT/drivers/audio" && fasm sis.asm ../../build-en_US/drivers/audio/sis.sys && kpack --nologo "../../build-en_US/drivers/audio/sis.sys" )
( cd "$ROOT/drivers/audio" && fasm sound.asm ../../build-en_US/drivers/audio/sound.sys && kpack --nologo "../../build-en_US/drivers/audio/sound.sys" )
( cd "$ROOT/drivers/audio" && fasm vt823x.asm ../../build-en_US/drivers/audio/vt823x.sys && kpack --nologo "../../build-en_US/drivers/audio/vt823x.sys" )
( cd "$ROOT/programs/develop/fasm/1.73" && echo lang fix en_US > ../../../../build-en_US/programs/develop/fasm/1.73/lang.inc )
( cd "$ROOT/programs/develop/fasm/1.73" && INCLUDE='../../..;../../../../build-en_US/programs/develop/fasm/1.73' fasm fasm.asm ../../../../build-en_US/programs/develop/fasm/1.73/fasm && kpack --nologo "../../../../build-en_US/programs/develop/fasm/1.73/fasm" )
( cd "$ROOT/drivers/audio/infinity" && fasm infinity.asm ../../../build-en_US/drivers/audio/infinity/infinity.sys && kpack --nologo "../../../build-en_US/drivers/audio/infinity/infinity.sys" )
( cd "$ROOT/drivers/i2chid" && fasm i2chid.asm ../../build-en_US/drivers/i2chid/i2chid.sys && kpack --nologo "../../build-en_US/drivers/i2chid/i2chid.sys" )
( cd "$ROOT/programs/testing/genfiles" && fasm GenFiles.asm ../../../build-en_US/programs/testing/genfiles/GenFiles && kpack --nologo "../../../build-en_US/programs/testing/genfiles/GenFiles" )
( cd "$ROOT/programs/other/pipet" && INCLUDE='../..' fasm -dlang=en_US pipet.asm ../../../build-en_US/programs/other/pipet/pipet&& kpack --nologo "../../../build-en_US/programs/other/pipet/pipet" )
( cd "$ROOT/programs/system/MyKey" && echo lang fix en_US > ../../../build-en_US/programs/system/MyKey/lang.inc )
( cd "$ROOT/programs/system/MyKey" && INCLUDE='../..;../../../build-en_US/programs/system/MyKey' fasm MyKey.asm ../../../build-en_US/programs/system/MyKey/MyKey && kpack --nologo "../../../build-en_US/programs/system/MyKey/MyKey" )
( cd "$ROOT/programs/develop/h2d2b" && echo lang fix en_US > ../../../build-en_US/programs/develop/h2d2b/lang.inc )
( cd "$ROOT/programs/develop/h2d2b" && INCLUDE='../..;../../../build-en_US/programs/develop/h2d2b' fasm h2d2b.asm ../../../build-en_US/programs/develop/h2d2b/h2d2b && kpack --nologo "../../../build-en_US/programs/develop/h2d2b/h2d2b" )
find "$ROOT/build-en_US" -type f -exec touch -d "2026-11-01 00:00:00" {} +   # fixed file dates on the floppy
( cd "$ROOT/data" && dd status=none if=/dev/zero of=../build-en_US/data/kolibri.img count=2880 bs=512  && mformat -f 1440 -i ../build-en_US/data/kolibri.img ::  && dd status=none if=../build-en_US/data/../kernel/trunk/bootloader/boot_fat12.bin of=../build-en_US/data/kolibri.img count=1 bs=512 conv=notrunc  && mmd -i ../build-en_US/data/kolibri.img "::3D"  && mmd -i ../build-en_US/data/kolibri.img "::DEMOS"  && mmd -i ../build-en_US/data/kolibri.img "::DEVELOP"  && mmd -i ../build-en_US/data/kolibri.img "::DRIVERS"  && mmd -i ../build-en_US/data/kolibri.img "::FONTS"  && mmd -i ../build-en_US/data/kolibri.img "::File Managers"  && mmd -i ../build-en_US/data/kolibri.img "::GAMES"  && mmd -i ../build-en_US/data/kolibri.img "::LIB"  && mmd -i ../build-en_US/data/kolibri.img "::MEDIA"  && mmd -i ../build-en_US/data/kolibri.img "::NETWORK"  && mmd -i ../build-en_US/data/kolibri.img "::SETTINGS"  && mcopy -moi ../build-en_US/data/kolibri.img "./../programs/macros.inc" "::MACROS.INC"  && mcopy -moi ../build-en_US/data/kolibri.img "./../programs/struct.inc" "::STRUCT.INC"  && mcopy -moi ../build-en_US/data/kolibri.img "common/wallpapers/T_Home.png" "::HOME.PNG"  && mcopy -moi ../build-en_US/data/kolibri.img "common/icons32.png" "::ICONS32.PNG"  && mcopy -moi ../build-en_US/data/kolibri.img "common/icons18.png" "::ICONS18.PNG"  && mcopy -moi ../build-en_US/data/kolibri.img "common/index_htm" "::INDEX.HTM"   && mcopy -moi ../build-en_US/data/kolibri.img "common/sine.mp3" "::SINE.MP3"  && mcopy -moi ../build-en_US/data/kolibri.img "en_US/lang.inc" "::LANG.INC"  && mcopy -moi ../build-en_US/data/kolibri.img "common/notify3.png" "::NOTIFY3.PNG"  && mcopy -moi ../build-en_US/data/kolibri.img "common/3d/house.3ds" "::3D/HOUSE.3DS"  && mcopy -moi ../build-en_US/data/kolibri.img "common/File Managers/icon2ext.ini" "::File Managers/ICON2EXT.INI"   && mcopy -moi ../build-en_US/data/kolibri.img "./../programs/network/ftpc/ftpc.ini" "::NETWORK/FTPC.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "common/network/ftpd.ini" "::NETWORK/FTPD.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "common/network/users.ini" "::NETWORK/USERS.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "common/settings/app.ini" "::SETTINGS/APP.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "common/settings/app_plus.ini" "::SETTINGS/APP_PLUS.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "common/settings/assoc.ini" "::SETTINGS/ASSOC.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "common/settings/AUTORUN.DAT" "::SETTINGS/AUTORUN.DAT"  && mcopy -moi ../build-en_US/data/kolibri.img "./../programs/develop/cedit/CEDIT.INI" "::SETTINGS/CEDIT.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "common/settings/docky.ini" "::SETTINGS/DOCKY.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "common/settings/fb2read.ini" "::SETTINGS/FB2READ.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "./../programs/other/ha/SETTINGS/HA.CFG" "::SETTINGS/HA.CFG"  && mcopy -moi ../build-en_US/data/kolibri.img "en_US/settings/icon.ini" "::SETTINGS/ICON.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/taskbar/keymap.key.kpack" "::SETTINGS/KEYMAP.KEY"  && mcopy -moi ../build-en_US/data/kolibri.img "en_US/settings/lang.ini" "::SETTINGS/LANG.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "en_US/settings/menu.dat" "::SETTINGS/MENU.DAT"  && mcopy -moi ../build-en_US/data/kolibri.img "common/settings/network.ini" "::SETTINGS/NETWORK.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "common/settings/system.ini" "::SETTINGS/SYSTEM.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "common/settings/taskbar.ini" "::SETTINGS/TASKBAR.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "common/settings/system.env" "::SETTINGS/SYSTEM.ENV"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/usb/usbother/usbdrv.dat" "::SETTINGS/USBDRV.DAT"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../data/en_US/welcome.htm.kpack" "::WELCOME.HTM"  && mcopy -moi ../build-en_US/data/kolibri.img "./../programs/develop/examples/example/example.asm" "::EXAMPLE.ASM"  && mcopy -moi ../build-en_US/data/kolibri.img "./../programs/develop/backy/Backy" "::DEVELOP/BACKY"  && mcopy -moi ../build-en_US/data/kolibri.img "common/File Managers/kfar.ini" "::File Managers/KFAR.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "./../programs/system/shell/bin/eng/.shell" "::SETTINGS/.shell"  && mcopy -moi ../build-en_US/data/kolibri.img "common/settings/games.ini" "::SETTINGS/GAMES.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "./../programs/system/MyKey/mykey.ini" "::SETTINGS/MYKEY.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "common/settings/syspanel.ini" "::SETTINGS/SYSPANEL.INI"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/../kernel/trunk/kernel.mnt" "::KERNEL.MNT"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/docky/docky" "::@DOCKY"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/other/ha/HA" "::@HA"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/icon_new/icon" "::@ICON"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/menu/menu" "::@MENU"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/notify3/notify" "::@NOTIFY"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/open/open" "::@OPEN"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/reshare/reshare" "::@RESHARE"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/scrsaver/scrsaver" "::@SS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/taskbar/TASKBAR" "::@TASKBAR"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/volume/volume" "::@VOLUME"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/other/ha/HACONFIG" "::HACONFIG"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/aclock/aclock" "::ACLOCK"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/apm/apm" "::APM"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/other/calc/calc" "::CALC"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/other/calcplus/calcplus" "::CALCPLUS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/calendar/calendar" "::CALENDAR"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/colrdial/color_dialog" "::COLRDIAL"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/cropflat/cropflat" "::CROPFLAT"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/cpu/cpu" "::CPU"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/testing/cpuid/CPUID" "::CPUID"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/docpack/docpack" "::DOCPACK"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../skins/../skins/Leency/Shkvorka/Shkvorka.skn" "::DEFAULT.SKN"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/testing/disptest/disptest" "::DISPTEST"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/end/light/end" "::END"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/eskin/eskin" "::ESKIN"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/gmon/gmon" "::GMON"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/hdd_info/hdd_info" "::HDD_INFO"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/testing/kbd/kbd" "::KBD"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/other/kpack/kpack" "::KPACK"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/launcher/launcher" "::LAUNCHER"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/loaddrv/loaddrv" "::LOADDRV"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/magnify/magnify" "::MAGNIFY"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/other/madmouse/madmouse" "::MADMOUSE"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/mousemul/mousemul" "::MOUSEMUL"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/other/mousepos/mousepos" "::MOUSEPOS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/MyKey/MyKey" "::MYKEY"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/testing/pcidev/PCIDEV" "::PCIDEV"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/rdsave/rdsave" "::RDSAVE"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/other/rtfread/rtfread" "::RTFREAD"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/searchap/searchap" "::SEARCHAP"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/scrshoot/scrshoot" "::SCRSHOOT"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/setup/setup" "::SETUP"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/skincfg/skincfg" "::SKINCFG"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/terminal/terminal" "::TERMINAL"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/testing/protection/test" "::TEST"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/tinypad/tinypad" "::TINYPAD"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/tinfo/tinfo" "::TINFO"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/other/Timer/Timer" "::TIMER"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/fs/unz/unz" "::UNZ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/zkey/ZKEY" "::ZKEY"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/3dwav/3dwav" "::3D/3DWAV"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/crownscr/crownscr" "::3D/CROWNSCR"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/3dcube2/3DCUBE2" "::3D/3DCUBE2"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/free3d04/free3d04" "::3D/FREE3D04"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/TinyGL/asm_fork/examples/gears" "::3D/GEARS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/ray/ray" "::3D/RAY"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/view3ds/view3ds" "::3D/VIEW3DS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/bcdclk/bcdclk" "::DEMOS/BCDCLK"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/buddhabrot/buddhabrot" "::DEMOS/BUDHBROT"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/eyes/eyes" "::DEMOS/EYES"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/firework/firework" "::DEMOS/FIREWORK"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/movback/movback" "::DEMOS/MOVBACK"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/plasma/plasma" "::DEMOS/PLASMA"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/spiral/spiral" "::DEMOS/SPIRAL"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/tinyfrac/tinyfrac" "::DEMOS/TINYFRAC"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/trantest/trantest" "::DEMOS/TRANTEST"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/tube/tube" "::DEMOS/TUBE"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/unvwater/unvwater" "::DEMOS/UNVWATER"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/web/web" "::DEMOS/WEB"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/demos/zeroline/zeroline" "::DEMOS/ZEROLINE"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/board/board" "::DEVELOP/BOARD"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/system/dbgboard/dbgboard" "::DEVELOP/DBGBOARD"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/charsets/charsets" "::DEVELOP/CHARSETS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/cObj/cObj" "::DEVELOP/COBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/entropyview/entropyview" "::DEVELOP/ENTROPYV"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/fasm/1.73/fasm" "::DEVELOP/FASM"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/testing/genfiles/GenFiles" "::DEVELOP/GENFILES"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/other/pipet/pipet" "::DEVELOP/PIPET"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/h2d2b/h2d2b" "::DEVELOP/H2D2B"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/heed/heed" "::DEVELOP/HEED"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/mtdbg/mtdbg" "::DEVELOP/MTDBG"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/mstate/mstate" "::DEVELOP/MSTATE"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/scancode/scancode" "::DEVELOP/SCANCODE"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/fs/kfar/kfar" "::File Managers/KFAR"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/fs/opendial/opendial" "::File Managers/OPENDIAL"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/fs/lod/lod" "::LOD"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/15/15" "::GAMES/15"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/max-freecell/freecell" "::GAMES/FREECELL"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/gomoku/gomoku" "::GAMES/GOMOKU"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/sq_game/SQ_GAME" "::GAMES/LIGHTS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/lines/lines" "::GAMES/LINES"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/MSquare/MSquare" "::GAMES/MSQUARE"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/pipes/pipes" "::GAMES/PIPES"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/pong/pong" "::GAMES/PONG"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/pong3/pong3" "::GAMES/PONG3"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/rsquare/rsquare" "::GAMES/RSQUARE"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/snake/snake" "::GAMES/SNAKE"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/sudoku/sudoku" "::GAMES/SUDOKU"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/sw/sw" "::GAMES/SW"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/tanks/tanks" "::GAMES/TANKS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/tetris/tetris" "::GAMES/TETRIS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/games/c4/c4" "::GAMES/C4"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/fs/kfar/kfar_arc/kfar_arc.obj" "::LIB/ARCHIVER.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/box_lib/box_lib.obj" "::LIB/BOX_LIB.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/buf2d/buf2d.obj" "::LIB/BUF2D.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/console_coff/console.obj" "::LIB/CONSOLE.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/zsea/plugins/png/cnv_png.obj" "::LIB/CNV_PNG.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/dll/dll.obj" "::LIB/DLL.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/http/http.obj" "::LIB/HTTP.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/libcrash/libcrash.obj" "::LIB/LIBCRASH.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/libs-dev/libgfx/libgfx.obj" "::LIB/LIBGFX.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/libs-dev/libimg/libimg.obj" "::LIB/LIBIMG.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/libs-dev/libini/libini.obj" "::LIB/LIBINI.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/libs-dev/libio/libio.obj" "::LIB/LIBIO.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/msgbox/msgbox.obj" "::LIB/MSGBOX.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/network/network.obj" "::LIB/NETWORK.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/proc_lib/proc_lib.obj" "::LIB/PROC_LIB.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/fontRasterWorks_unicode/RasterWorks.obj" "::LIB/RASTERWORKS.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/sorter/sort.obj" "::LIB/SORT.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/develop/libraries/TinyGL/asm_fork/tinygl.obj" "::LIB/TINYGL.OBJ"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/animage/animage" "::MEDIA/ANIMAGE"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/FillScr/fillscr" "::MEDIA/FILLSCR"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/kiv/kiv" "::MEDIA/KIV"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/listplay/listplay" "::MEDIA/LISTPLAY"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/midamp/midamp" "::MEDIA/MIDAMP"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/mp3info/mp3info" "::MEDIA/MP3INFO"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/palitra/palitra" "::MEDIA/PALITRA"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/piano/piano" "::MEDIA/PIANO"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/piano/piano.map" "::MEDIA/PIANO.MAP"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/media/startmus/STARTMUS" "::MEDIA/STARTMUS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/ping/ping" "::NETWORK/PING"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/netcfg/netcfg" "::NETWORK/NETCFG"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/netstat/netstat" "::NETWORK/NETSTAT"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/netsurf/netsurf" "::NETWORK/NETSURF"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/nslookup/nslookup" "::NETWORK/NSLOOKUP"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/pasta/pasta" "::NETWORK/PASTA"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/synergyc/synergyc" "::NETWORK/SYNERGYC"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/sntp/sntp" "::NETWORK/SNTP"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/telnet/telnet" "::NETWORK/TELNET"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/zeroconf/zeroconf" "::NETWORK/@ZEROCONF"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/ftpc/ftpc" "::NETWORK/FTPC"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/ftpd/ftpd" "::NETWORK/FTPD"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/tftpc/tftpc" "::NETWORK/TFTPC"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/ircc/ircc" "::NETWORK/IRCC"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/httpget/httpget" "::NETWORK/HTTPGET"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../programs/network/vncc/vncc" "::NETWORK/VNCC"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/video/vidintel.sys" "::DRIVERS/VIDINTEL.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/3c59x.sys" "::DRIVERS/3C59X.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/ar81xx.sys" "::DRIVERS/AR81XX.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/dec21x4x.sys" "::DRIVERS/DEC21X4X.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/forcedeth.sys" "::DRIVERS/FORCEDETH.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/i8254x.sys" "::DRIVERS/I8254X.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/i8255x.sys" "::DRIVERS/I8255X.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/mtd80x.sys" "::DRIVERS/MTD80X.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/pcnet32.sys" "::DRIVERS/PCNET32.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/R6040.sys" "::DRIVERS/R6040.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/rhine.sys" "::DRIVERS/RHINE.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/RTL8029.sys" "::DRIVERS/RTL8029.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/RTL8139.sys" "::DRIVERS/RTL8139.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/RTL8169.sys" "::DRIVERS/RTL8169.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/ethernet/sis900.sys" "::DRIVERS/SIS900.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/usb/uhci.sys" "::DRIVERS/UHCI.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/usb/ohci.sys" "::DRIVERS/OHCI.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/usb/ehci.sys" "::DRIVERS/EHCI.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/usb/xhci/xhci.sys" "::DRIVERS/XHCI.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/usb/usbhid/usbhid.sys" "::DRIVERS/USBHID.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/usb/usbftdi/usbftdi.sys" "::DRIVERS/USBFTDI.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/usb/usbother/usbother.sys" "::DRIVERS/USBOTHER.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/usb/usbnet/usbcdc.sys" "::DRIVERS/USBCDC.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/usb/usbnet/usbrndis.sys" "::DRIVERS/USBRNDIS.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/usb/usbstor.sys" "::DRIVERS/USBSTOR.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/video/rdc.sys" "::DRIVERS/RDC.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/serial/serial.sys" "::DRIVERS/SERIAL.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/mouse/commouse.sys" "::DRIVERS/COMMOUSE.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/mouse/ps2mouse4d/ps2mouse.sys" "::DRIVERS/PS2MOUSE.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/disk/tmpdisk.sys" "::DRIVERS/TMPDISK.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/disk/virt_disk.sys" "::DRIVERS/VIRTDISK.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/audio/intel_hda/hdaudio.sys" "::DRIVERS/HDAUDIO.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/audio/sb16/sb16.sys" "::DRIVERS/SB16.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/audio/sound.sys" "::DRIVERS/SOUND.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/audio/infinity/infinity.sys" "::DRIVERS/INFINITY.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/audio/ac97.sys" "::DRIVERS/AC97.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/audio/cmi8738.sys" "::DRIVERS/CMI8738.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/audio/es1371.sys" "::DRIVERS/ES1371.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/audio/emu10k1x.sys" "::DRIVERS/EMU10K1X.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/audio/fm801.sys" "::DRIVERS/FM801.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/audio/vt823x.sys" "::DRIVERS/VT823X.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/audio/sis.sys" "::DRIVERS/SIS.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../drivers/sdhci/sdhci.sys" "::DRIVERS/SDHCI.SYS"  && mcopy -moi ../build-en_US/data/kolibri.img "../build-en_US/data/../drivers/i2chid/i2chid.sys" "::DRIVERS/I2CHID.SYS" )
python3 "$ROOT/hummingbird-tools/fat12-fix-times.py" "$ROOT/build-en_US/data/kolibri.img"   # fixed dates in every directory entry
echo "built: $ROOT/build-en_US/data/kolibri.img"
