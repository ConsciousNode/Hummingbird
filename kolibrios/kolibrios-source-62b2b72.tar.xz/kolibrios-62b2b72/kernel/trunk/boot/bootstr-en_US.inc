;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;                                                              ;;
;; Copyright (C) KolibriOS team 2004-2024. All rights reserved. ;;
;; Distributed under terms of the GNU General Public License    ;;
;;                                                              ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


;======================================================================
;
;                           BOOT DATA
;
;======================================================================


d80x25_bottom:
          db       186,' KolibriOS comes with ABSOLUTELY NO WARRANTY. See file COPYING for details    ',186
          db       186,' If you find any bugs, please report them at: https://git.kolibrios.org       ',186
          line_full_bottom
d80x25_bottom_num = 3

msg_apm   db      " APM x.x ", 0
novesa    db      "Display: EGA/CGA",13,10,0
s_vesa    db      "Version of VESA: "
  .ver    db      "?.?",13,10,0

gr_mode   db      "Select a videomode: ",13,10,0

ask_bd    db      "Add disks visible by BIOS emulated in V86-mode? [1-yes, 2-no]: ",0

if defined extended_primary_loader
bdev      db      "Load ramdisk from [1-floppy; 2-kolibri.img; 3-don't load]: ",0
else
bdev      db      "Load ramdisk from [1-floppy; 2-C:\kolibri.img (FAT32);"
          db      13,10,186,"                   "
          db      "3-preloaded ram-image (flash-disk, dualboot, "
          db      13,10,186,"                   "
          db      "kernel restart, etc.)]: ",0
end if

prnotfnd  db      "Fatal - Videomode not found.",0

not386    db      "Fatal - CPU 386+ required.",0
fatalsel  db      "Fatal - Graphics mode not supported by hardware.",0
pres_key  db      "Press any key to choose a new videomode.",0
badsect   db      13,10,186," Fatal - Bad sector. Replace floppy.",0
memmovefailed db  13,10,186," Fatal - Int 0x15 move failed.",0
okt       db      " ... OK"
linef     db      13,10,0
diskload  db      "Loading diskette: 00 %",8,8,8,8,0
pros      db      "00"
backspace2 db     8,8,0
boot_dev  db      0  ; 0=floppy, 1=hd
start_msg db      "Press [abcde] to change settings, press [Enter] to continue booting",13,10,0
time_msg  db      " or wait "
time_str  db      " 5 seconds"
          db      " to continue automatically",13,10,0
current_cfg_msg db "Boot options:",13,10,0
curvideo_msg       db " [a] Video mode...............",0
usebd_msg          db " [b] BIOS disks...............",0
debug_mode_msg     db " [c] On-screen debug..........",0
launcher_msg       db " [d] Start LAUNCHER...........",0
preboot_device_msg db " [e] Boot from................",0

mode0     db      "320x200, EGA/CGA 256 colors",13,10,0
mode9     db      "640x480, VGA 16 colors",13,10,0

on_msg    db      "on",13,10,0
off_msg   db      "off",13,10,0

ask_debug      db "Duplicate debug output to the screen? [1-yes, 2-no]: ",0

ask_launcher   db "Autostart applications and services after kernel is loaded? [1-yes, 2-no]: ",0


if defined extended_primary_loader
preboot_device_msgs dw 0,pdm1,pdm2,pdm3,0
pdm1      db      "real floppy",13,10,0
pdm2      db      "C:\kolibri.img (FAT32)",13,10,0
pdm3      db      "do not use floppy image",13,10,0
else
preboot_device_msgs dw 0,pdm1,pdm2,pdm3,pdm4,0
pdm1      db      "real floppy",13,10,0
pdm2      db      "C:\kolibri.img (FAT32)",13,10,0
pdm3      db      "preloaded ram-image",13,10,0
pdm4      db      "create blank image",13,10,0
end if

loading_msg db    "Loading KolibriOS...",0

if ~ defined extended_primary_loader
save_quest db     "New settings have been applied.",13,10,13,10,186
           db     " Do you want to save them for future boots?",13,10,186
           db     " Answer 'yes' only if your booting device is writable. [y/n]: ",0
loader_block_error db "Bootloader data invalid. Stopped.",0
write_err_msg db "Recording the configuration has failed. Press any key to resume booting...",0
end if
low_memory_error db "Not enough RAM: KolibriOS needs at least 9 MB. Stopped.",0

_st latin1 '║                   ┌───────────────────────────────┬─┐',13,10,0
_r1 latin1 '║                   │  320x200  EGA/CGA 256 colors  │ │',13,10,0
_r2 latin1 '║                   │  640x480  VGA 16 colors       │ │',13,10,0
_rs latin1 '║                   │  ????x????@??  SVGA VESA      │ │',13,10,0
_bt latin1 '║                   └───────────────────────────────┴─┘',13,10,0

remark1 db      "Default values were selected to match most configurations, but not all.",0
remark2 db      "If the system does not boot, try to disable option [b]. If the system gets",0
remark3 db      "stuck after booting, enable option [c], disable option [d] and take photo.",0
remarks dw      remark1, remark2, remark3
num_remarks = 3
