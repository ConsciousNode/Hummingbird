#!/usr/bin/env python3
# Hummingbird reproducibility step: set every FAT12 directory-entry date/time on a
# 1.44 MB floppy image to one fixed value (2026-11-01 00:00:00), so builds are byte-identical.
import struct, sys
img = bytearray(open(sys.argv[1], 'rb').read())
bps, spc, rsv, nfat, nroot, _, _, spf = struct.unpack_from('<HBHBHHBH', img, 11)
fat = img[rsv * bps:(rsv + spf) * bps]
root = (rsv + nfat * spf) * bps
data = root + nroot * 32
date = ((2026 - 1980) << 9) | (11 << 5) | 1
def fat12(n):
    v = struct.unpack_from('<H', fat, n * 3 // 2)[0]
    return v >> 4 if n & 1 else v & 0xFFF
def chain(c):
    while 2 <= c < 0xFF8:
        yield data + (c - 2) * spc * bps
        c = fat12(c)
def walk(off, count, seen):
    for i in range(count):
        e = off + i * 32
        if img[e] == 0: return
        if img[e] == 0xE5 or img[e + 11] == 0x0F: continue      # deleted / long-name entry
        img[e + 13] = 0                                          # creation 10ms units
        struct.pack_into('<HH', img, e + 14, 0, date)            # creation time, date
        struct.pack_into('<H', img, e + 18, date)                # last access date
        struct.pack_into('<HH', img, e + 22, 0, date)            # write time, date
        if img[e + 11] & 0x10 and img[e] != ord('.'):
            c = struct.unpack_from('<H', img, e + 26)[0]
            if c not in seen:
                seen.add(c)
                for sec in chain(c): walk(sec, spc * bps // 32, seen)
walk(root, nroot, set())
open(sys.argv[1], 'wb').write(img)
